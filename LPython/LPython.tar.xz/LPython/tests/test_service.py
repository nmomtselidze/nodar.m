import unittest
import os
import tempfile
from datetime import datetime
from src.task_manager.models import Task, TaskStatus, TaskPriority
from src.task_manager.service import TaskService


class TestTaskService(unittest.TestCase):
    def setUp(self):
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix=".db")
        self.db_path = self.temp_db.name
        self.temp_db.close()
        self.service = TaskService(self.db_path)

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.unlink(self.db_path)

    def test_create_task(self):
        task = self.service.create_task(
            title="Test Task",
            description="Test Description",
            priority=TaskPriority.HIGH,
        )
        self.assertIsNotNone(task.id)
        self.assertEqual(task.title, "Test Task")
        self.assertEqual(task.description, "Test Description")
        self.assertEqual(task.priority, TaskPriority.HIGH)
        self.assertEqual(task.status, TaskStatus.PENDING)

    def test_create_task_with_due_date(self):
        due_date = datetime(2024, 12, 31)
        task = self.service.create_task(
            title="Task with Due Date",
            due_date=due_date,
        )
        self.assertIsNotNone(task.due_date)
        self.assertEqual(task.due_date.date(), due_date.date())

    def test_get_task(self):
        created_task = self.service.create_task(title="Test Task")
        retrieved_task = self.service.get_task(created_task.id)
        self.assertIsNotNone(retrieved_task)
        self.assertEqual(retrieved_task.id, created_task.id)
        self.assertEqual(retrieved_task.title, "Test Task")

    def test_get_nonexistent_task(self):
        task = self.service.get_task(999)
        self.assertIsNone(task)

    def test_list_all_tasks(self):
        self.service.create_task(title="Task 1")
        self.service.create_task(title="Task 2")
        self.service.create_task(title="Task 3")
        tasks = self.service.list_all_tasks()
        self.assertEqual(len(tasks), 3)

    def test_list_tasks_by_status(self):
        task1 = self.service.create_task(title="Task 1")
        task2 = self.service.create_task(title="Task 2")
        task3 = self.service.create_task(title="Task 3")
        
        self.service.update_task_status(task1.id, TaskStatus.COMPLETED)
        self.service.update_task_status(task2.id, TaskStatus.IN_PROGRESS)
        
        pending_tasks = self.service.list_tasks_by_status(TaskStatus.PENDING)
        in_progress_tasks = self.service.list_tasks_by_status(TaskStatus.IN_PROGRESS)
        completed_tasks = self.service.list_tasks_by_status(TaskStatus.COMPLETED)
        
        self.assertEqual(len(pending_tasks), 1)
        self.assertEqual(len(in_progress_tasks), 1)
        self.assertEqual(len(completed_tasks), 1)

    def test_list_tasks_by_priority(self):
        task1 = self.service.create_task(title="Task 1", priority=TaskPriority.HIGH)
        task2 = self.service.create_task(title="Task 2", priority=TaskPriority.LOW)
        task3 = self.service.create_task(title="Task 3", priority=TaskPriority.HIGH)
        
        high_priority_tasks = self.service.list_tasks_by_priority(TaskPriority.HIGH)
        low_priority_tasks = self.service.list_tasks_by_priority(TaskPriority.LOW)
        
        self.assertEqual(len(high_priority_tasks), 2)
        self.assertEqual(len(low_priority_tasks), 1)

    def test_update_task_status(self):
        task = self.service.create_task(title="Test Task")
        updated_task = self.service.update_task_status(task.id, TaskStatus.IN_PROGRESS)
        self.assertIsNotNone(updated_task)
        self.assertEqual(updated_task.status, TaskStatus.IN_PROGRESS)

    def test_update_task_priority(self):
        task = self.service.create_task(title="Test Task")
        updated_task = self.service.update_task_priority(task.id, TaskPriority.HIGH)
        self.assertIsNotNone(updated_task)
        self.assertEqual(updated_task.priority, TaskPriority.HIGH)

    def test_update_task_details(self):
        task = self.service.create_task(title="Original Title", description="Original Description")
        updated_task = self.service.update_task_details(
            task.id,
            title="Updated Title",
            description="Updated Description",
        )
        self.assertIsNotNone(updated_task)
        self.assertEqual(updated_task.title, "Updated Title")
        self.assertEqual(updated_task.description, "Updated Description")

    def test_update_task_details_partial(self):
        task = self.service.create_task(title="Original Title", description="Original Description")
        updated_task = self.service.update_task_details(task.id, title="Updated Title")
        self.assertIsNotNone(updated_task)
        self.assertEqual(updated_task.title, "Updated Title")
        self.assertEqual(updated_task.description, "Original Description")

    def test_delete_task(self):
        task = self.service.create_task(title="To Delete")
        success = self.service.delete_task(task.id)
        self.assertTrue(success)
        deleted_task = self.service.get_task(task.id)
        self.assertIsNone(deleted_task)

    def test_search_tasks(self):
        task1 = self.service.create_task(title="Buy groceries", description="Milk and eggs")
        task2 = self.service.create_task(title="Clean house", description="Vacuum and dust")
        task3 = self.service.create_task(title="Grocery list", description="Plan meals")
        
        results = self.service.search_tasks("grocer")
        self.assertEqual(len(results), 2)
        
        results = self.service.search_tasks("clean")
        self.assertEqual(len(results), 1)
        
        results = self.service.search_tasks("vacuum")
        self.assertEqual(len(results), 1)

    def test_get_pending_tasks(self):
        task1 = self.service.create_task(title="Task 1")
        task2 = self.service.create_task(title="Task 2")
        self.service.update_task_status(task1.id, TaskStatus.COMPLETED)
        
        pending_tasks = self.service.get_pending_tasks()
        self.assertEqual(len(pending_tasks), 1)
        self.assertEqual(pending_tasks[0].id, task2.id)

    def test_get_in_progress_tasks(self):
        task1 = self.service.create_task(title="Task 1")
        task2 = self.service.create_task(title="Task 2")
        self.service.update_task_status(task1.id, TaskStatus.IN_PROGRESS)
        
        in_progress_tasks = self.service.get_in_progress_tasks()
        self.assertEqual(len(in_progress_tasks), 1)
        self.assertEqual(in_progress_tasks[0].id, task1.id)

    def test_get_completed_tasks(self):
        task1 = self.service.create_task(title="Task 1")
        task2 = self.service.create_task(title="Task 2")
        self.service.update_task_status(task1.id, TaskStatus.COMPLETED)
        
        completed_tasks = self.service.get_completed_tasks()
        self.assertEqual(len(completed_tasks), 1)
        self.assertEqual(completed_tasks[0].id, task1.id)

    def test_get_high_priority_tasks(self):
        task1 = self.service.create_task(title="Task 1", priority=TaskPriority.HIGH)
        task2 = self.service.create_task(title="Task 2", priority=TaskPriority.LOW)
        task3 = self.service.create_task(title="Task 3", priority=TaskPriority.HIGH)
        
        high_priority_tasks = self.service.get_high_priority_tasks()
        self.assertEqual(len(high_priority_tasks), 2)

    def test_mark_task_complete(self):
        task = self.service.create_task(title="Test Task")
        the_task = self.service.mark_task_complete(task.id)
        self.assertIsNotNone(the_task)
        self.assertEqual(the_task.status, TaskStatus.COMPLETED)

    def test_mark_task_in_progress(self):
        task = self.service.create_task(title="Test Task")
        the_task = self.service.mark_task_in_progress(task.id)
        self.assertIsNotNone(the_task)
        self.assertEqual(the_task.status, TaskStatus.IN_PROGRESS)

    def test_clear_all_tasks(self):
        self.service.create_task(title="Task 1")
        self.service.create_task(title="Task 2")
        success = self.service.clear_all_tasks()
        self.assertTrue(success)
        tasks = self.service.list_all_tasks()
        self.assertEqual(len(tasks), 0)


if __name__ == "__main__":
    unittest.main()
