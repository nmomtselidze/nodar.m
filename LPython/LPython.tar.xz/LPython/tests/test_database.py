import unittest
import os
import tempfile
from datetime import datetime
from src.task_manager.models import Task, TaskStatus, TaskPriority
from src.task_manager.database import Database


class TestDatabase(unittest.TestCase):
    def setUp(self):
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix=".db")
        self.db_path = self.temp_db.name
        self.temp_db.close()
        self.db = Database(self.db_path)

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.unlink(self.db_path)

    def test_init_db(self):
        self.assertTrue(os.path.exists(self.db_path))

    def test_add_task(self):
        task = Task(
            title="Test Task",
            description="Test Description",
            status=TaskStatus.PENDING,
            priority=TaskPriority.HIGH,
        )
        added_task = self.db.add_task(task)
        self.assertIsNotNone(added_task.id)
        self.assertEqual(added_task.title, "Test Task")
        self.assertEqual(added_task.description, "Test Description")

    def test_get_task(self):
        task = Task(title="Test Task", description="Test Description")
        added_task = self.db.add_task(task)
        retrieved_task = self.db.get_task(added_task.id)
        self.assertIsNotNone(retrieved_task)
        self.assertEqual(retrieved_task.id, added_task.id)
        self.assertEqual(retrieved_task.title, "Test Task")

    def test_get_nonexistent_task(self):
        task = self.db.get_task(999)
        self.assertIsNone(task)

    def test_get_all_tasks(self):
        task1 = Task(title="Task 1")
        task2 = Task(title="Task 2")
        self.db.add_task(task1)
        self.db.add_task(task2)
        tasks = self.db.get_all_tasks()
        self.assertEqual(len(tasks), 2)

    def test_update_task(self):
        task = Task(title="Original Title")
        added_task = self.db.add_task(task)
        added_task.title = "Updated Title"
        added_task.description = "Updated Description"
        success = self.db.update_task(added_task)
        self.assertTrue(success)
        updated_task = self.db.get_task(added_task.id)
        self.assertEqual(updated_task.title, "Updated Title")
        self.assertEqual(updated_task.description, "Updated Description")

    def test_delete_task(self):
        task = Task(title="To Delete")
        added_task = self.db.add_task(task)
        success = self.db.delete_task(added_task.id)
        self.assertTrue(success)
        deleted_task = self.db.get_task(added_task.id)
        self.assertIsNone(deleted_task)

    def test_delete_nonexistent_task(self):
        success = self.db.delete_task(999)
        self.assertFalse(success)

    def test_get_tasks_by_status(self):
        task1 = Task(title="Task 1", status=TaskStatus.PENDING)
        task2 = Task(title="Task 2", status=TaskStatus.COMPLETED)
        task3 = Task(title="Task 3", status=TaskStatus.PENDING)
        self.db.add_task(task1)
        self.db.add_task(task2)
        self.db.add_task(task3)
        pending_tasks = self.db.get_tasks_by_status(TaskStatus.PENDING)
        self.assertEqual(len(pending_tasks), 2)
        completed_tasks = self.db.get_tasks_by_status(TaskStatus.COMPLETED)
        self.assertEqual(len(completed_tasks), 1)

    def test_get_tasks_by_priority(self):
        task1 = Task(title="Task 1", priority=TaskPriority.HIGH)
        task2 = Task(title="Task 2", priority=TaskPriority.LOW)
        task3 = Task(title="Task 3", priority=TaskPriority.HIGH)
        self.db.add_task(task1)
        self.db.add_task(task2)
        self.db.add_task(task3)
        high_priority_tasks = self.db.get_tasks_by_priority(TaskPriority.HIGH)
        self.assertEqual(len(high_priority_tasks), 2)
        low_priority_tasks = self.db.get_tasks_by_priority(TaskPriority.LOW)
        self.assertEqual(len(low_priority_tasks), 1)

    def test_task_with_due_date(self):
        due_date = datetime(2024, 12, 31)
        task = Task(title="Task with Due Date", due_date=due_date)
        added_task = self.db.add_task(task)
        retrieved_task = self.db.get_task(added_task.id)
        self.assertIsNotNone(retrieved_task.due_date)
        self.assertEqual(retrieved_task.due_date.date(), due_date.date())

    def test_clear_all_tasks(self):
        task1 = Task(title="Task 1")
        task2 = Task(title="Task 2")
        self.db.add_task(task1)
        self.db.add_task(task2)
        success = self.db.clear_all_tasks()
        self.assertTrue(success)
        tasks = self.db.get_all_tasks()
        self.assertEqual(len(tasks), 0)

    def test_clear_empty_database(self):
        success = self.db.clear_all_tasks()
        self.assertFalse(success)


if __name__ == "__main__":
    unittest.main()
