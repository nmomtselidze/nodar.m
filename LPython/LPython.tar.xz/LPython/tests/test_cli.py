import unittest
import os
import tempfile
import sys
from io import StringIO
from unittest.mock import patch
from src.task_manager.cli import parse_date, format_task
from src.task_manager.models import Task, TaskStatus, TaskPriority


class TestCLIHelpers(unittest.TestCase):
    def test_parse_date_valid(self):
        date = parse_date("2024-01-01")
        self.assertIsNotNone(date)
        self.assertEqual(date.year, 2024)
        self.assertEqual(date.month, 1)
        self.assertEqual(date.day, 1)

    def test_parse_date_with_time(self):
        date = parse_date("2024-01-01T12:30:00")
        self.assertIsNotNone(date)
        self.assertEqual(date.hour, 12)
        self.assertEqual(date.minute, 30)

    def test_parse_date_none(self):
        date = parse_date(None)
        self.assertIsNone(date)

    def test_parse_date_invalid(self):
        with patch('sys.exit') as mock_exit:
            parse_date("invalid-date")
            mock_exit.assert_called_once()

    def test_format_task(self):
        task = Task(
            id=1,
            title="Test Task",
            description="Test Description",
            status=TaskStatus.PENDING,
            priority=TaskPriority.HIGH,
        )
        formatted = format_task(task)
        self.assertIn("[1]", formatted)
        self.assertIn("Test Task", formatted)
        self.assertIn("Test Description", formatted)
        self.assertIn("pending", formatted)
        self.assertIn("high", formatted)

    def test_format_task_in_progress(self):
        task = Task(
            id=1,
            title="Test Task",
            status=TaskStatus.IN_PROGRESS,
            priority=TaskPriority.MEDIUM,
        )
        formatted = format_task(task)
        self.assertIn("in_progress", formatted)
        self.assertIn("medium", formatted)

    def test_format_task_completed(self):
        task = Task(
            id=1,
            title="Test Task",
            status=TaskStatus.COMPLETED,
            priority=TaskPriority.LOW,
        )
        formatted = format_task(task)
        self.assertIn("completed", formatted)
        self.assertIn("low", formatted)


class TestCLICommands(unittest.TestCase):
    def setUp(self):
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix=".db")
        self.db_path = self.temp_db.name
        self.temp_db.close()

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.unlink(self.db_path)

    @patch('sys.stdout', new_callable=StringIO)
    def test_cmd_add(self, mock_stdout):
        from src.task_manager.cli import cmd_add
        from argparse import Namespace
        
        args = Namespace(
            db=self.db_path,
            title="Test Task",
            description="Test Description",
            priority="high",
            due_date=None,
        )
        cmd_add(args)
        output = mock_stdout.getvalue()
        self.assertIn("Task created", output)
        self.assertIn("Test Task", output)

    @patch('sys.stdout', new_callable=StringIO)
    def test_cmd_list_empty(self, mock_stdout):
        from src.task_manager.cli import cmd_list
        from argparse import Namespace
        
        args = Namespace(db=self.db_path, status=None, priority=None)
        cmd_list(args)
        output = mock_stdout.getvalue()
        self.assertIn("No tasks found", output)

    @patch('sys.stdout', new_callable=StringIO)
    def test_cmd_list_with_tasks(self, mock_stdout):
        from src.task_manager.cli import cmd_list, cmd_add
        from argparse import Namespace
        
        add_args = Namespace(
            db=self.db_path,
            title="Task 1",
            description="Description 1",
            priority="medium",
            due_date=None,
        )
        cmd_add(add_args)
        
        list_args = Namespace(db=self.db_path, status=None, priority=None)
        cmd_list(list_args)
        output = mock_stdout.getvalue()
        self.assertIn("Found 1 task", output)
        self.assertIn("Task 1", output)

    @patch('sys.stdout', new_callable=StringIO)
    @patch('sys.exit')
    def test_cmd_show_nonexistent(self, mock_exit, mock_stdout):
        from src.task_manager.cli import cmd_show
        from argparse import Namespace
        
        args = Namespace(db=self.db_path, id=999)
        cmd_show(args)
        mock_exit.assert_called_once()
        output = mock_stdout.getvalue()
        self.assertIn("not found", output)
        # Verify format_task was not called since task was not found

    @patch('sys.stdout', new_callable=StringIO)
    @patch('sys.exit')
    def test_cmd_delete_nonexistent(self, mock_exit, mock_stdout):
        from src.task_manager.cli import cmd_delete
        from argparse import Namespace
        
        args = Namespace(db=self.db_path, id=999)
        cmd_delete(args)
        mock_exit.assert_called_once()
        output = mock_stdout.getvalue()
        self.assertIn("not found", output)

    @patch('sys.stdout', new_callable=StringIO)
    def test_cmd_search_empty(self, mock_stdout):
        from src.task_manager.cli import cmd_search
        from argparse import Namespace
        
        args = Namespace(db=self.db_path, query="test")
        cmd_search(args)
        output = mock_stdout.getvalue()
        self.assertIn("No tasks matching", output)


if __name__ == "__main__":
    unittest.main()
