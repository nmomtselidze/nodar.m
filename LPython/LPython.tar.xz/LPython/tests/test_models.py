import unittest
from datetime import datetime
from src.task_manager.models import Task, TaskStatus, TaskPriority


class TestTask(unittest.TestCase):
    def test_task_creation(self):
        task = Task(
            title="Test Task",
            description="Test Description",
            status=TaskStatus.PENDING,
            priority=TaskPriority.HIGH,
        )
        self.assertEqual(task.title, "Test Task")
        self.assertEqual(task.description, "Test Description")
        self.assertEqual(task.status, TaskStatus.PENDING)
        self.assertEqual(task.priority, TaskPriority.HIGH)
        self.assertIsNone(task.id)
        self.assertIsNone(task.due_date)

    def test_task_defaults(self):
        task = Task(title="Default Task")
        self.assertEqual(task.title, "Default Task")
        self.assertEqual(task.description, "")
        self.assertEqual(task.status, TaskStatus.PENDING)
        self.assertEqual(task.priority, TaskPriority.MEDIUM)
        self.assertIsNotNone(task.created_at)
        self.assertIsNotNone(task.updated_at)

    def test_task_to_dict(self):
        task = Task(
            id=1,
            title="Test Task",
            description="Test Description",
            status=TaskStatus.IN_PROGRESS,
            priority=TaskPriority.LOW,
            due_date=datetime(2024, 1, 1),
        )
        task_dict = task.to_dict()
        self.assertEqual(task_dict["id"], 1)
        self.assertEqual(task_dict["title"], "Test Task")
        self.assertEqual(task_dict["description"], "Test Description")
        self.assertEqual(task_dict["status"], "in_progress")
        self.assertEqual(task_dict["priority"], "low")
        self.assertEqual(task_dict["due_date"], "2024-01-01T00:00:00")

    def test_task_from_dict(self):
        task_dict = {
            "id": 1,
            "title": "Test Task",
            "description": "Test Description",
            "status": "completed",
            "priority": "high",
            "created_at": "2024-01-01T00:00:00",
            "updated_at": "2024-01-02T00:00:00",
            "due_date": "2024-01-03T00:00:00",
        }
        task = Task.from_dict(task_dict)
        self.assertEqual(task.id, 1)
        self.assertEqual(task.title, "Test Task")
        self.assertEqual(task.description, "Test Description")
        self.assertEqual(task.status, TaskStatus.COMPLETED)
        self.assertEqual(task.priority, TaskPriority.HIGH)
        self.assertEqual(task.due_date, datetime(2024, 1, 3, 0, 0))

    def test_task_from_dict_with_defaults(self):
        task_dict = {
            "title": "Minimal Task",
            "created_at": "2024-01-01T00:00:00",
            "updated_at": "2024-01-01T00:00:00",
        }
        task = Task.from_dict(task_dict)
        self.assertEqual(task.title, "Minimal Task")
        self.assertEqual(task.status, TaskStatus.PENDING)
        self.assertEqual(task.priority, TaskPriority.MEDIUM)
        self.assertIsNone(task.due_date)

    def test_task_status_enum(self):
        self.assertEqual(TaskStatus.PENDING.value, "pending")
        self.assertEqual(TaskStatus.IN_PROGRESS.value, "in_progress")
        self.assertEqual(TaskStatus.COMPLETED.value, "completed")

    def test_task_priority_enum(self):
        self.assertEqual(TaskPriority.LOW.value, "low")
        self.assertEqual(TaskPriority.MEDIUM.value, "medium")
        self.assertEqual(TaskPriority.HIGH.value, "high")


if __name__ == "__main__":
    unittest.main()
