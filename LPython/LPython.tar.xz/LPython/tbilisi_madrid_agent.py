"""
Custom Travel Agent for Tbilisi to Madrid Trip
Demonstrates how LP can solve a specific travel planning task.
"""

from datetime import datetime, timedelta
from typing import Dict, Any, Optional
from src.task_manager.models import (
    LoopRun, LoopRunStatus, TriggerType,
    SkillExecution, SkillExecutionStatus,
    HumanGate, GateType, GateDecision,
    LoopState, StateType
)


class TbilisiMadridAgent:
    """
    A specialized travel agent for Tbilisi to Madrid trip.
    Focuses on budget-friendly travel to visit grandson at Nebrija University.
    """

    def __init__(self):
        self.current_loop_run: Optional[LoopRun] = None
        self.skill_executions: list[SkillExecution] = []
        self.human_gates: list[HumanGate] = []
        self.loop_states: dict[str, LoopState] = {}

    def start_travel_planning(self, user_request: Dict[str, Any]) -> LoopRun:
        """Start the travel planning process for Tbilisi to Madrid trip."""
        print("🚀 Starting Tbilisi to Madrid travel planning...")
        
        self.current_loop_run = LoopRun(
            started_at=datetime.now(),
            status=LoopRunStatus.RUNNING,
            trigger_type=TriggerType.MANUAL,
            trigger_metadata={"user_request": user_request},
            tasks_processed=0,
            tasks_created=0,
            tasks_updated=0,
            tasks_deleted=0
        )
        
        print(f"✓ LoopRun {self.current_loop_run.id} started")
        print(f"  Origin: {user_request['origin']}")
        print(f"  Destination: {user_request['destination']}")
        print(f"  Dates: {user_request['start_date']} to {user_request['end_date']}")
        print(f"  Budget: ${user_request['daily_budget']}/day for hotel")
        print(f"  Purpose: {user_request['purpose']}")
        
        return self.current_loop_run

    def execute_skill(self, skill_name: str, input_params: Dict[str, Any]) -> SkillExecution:
        """Execute a travel planning skill."""
        print(f"\n🤖 Executing skill: {skill_name}")
        
        skill_execution = SkillExecution(
            loop_run_id=self.current_loop_run.id if self.current_loop_run else None,
            skill_name=skill_name,
            started_at=datetime.now(),
            status=SkillExecutionStatus.RUNNING,
            input_params=input_params
        )
        
        try:
            result = self._simulate_skill_execution(skill_name, input_params)
            
            skill_execution.status = SkillExecutionStatus.COMPLETED
            skill_execution.completed_at = datetime.now()
            skill_execution.output_result = result
            skill_execution.execution_time_ms = int(
                (skill_execution.completed_at - skill_execution.started_at).total_seconds() * 1000
            )
            skill_execution.token_usage = len(str(result))
            
            print(f"✓ Skill {skill_name} completed in {skill_execution.execution_time_ms}ms")
            
        except Exception as e:
            skill_execution.status = SkillExecutionStatus.FAILED
            skill_execution.completed_at = datetime.now()
            skill_execution.error_message = str(e)
            print(f"✗ Skill {skill_name} failed: {e}")
        
        self.skill_executions.append(skill_execution)
        
        if self.current_loop_run:
            self.current_loop_run.tasks_processed += 1
        
        return skill_execution

    def _simulate_skill_execution(self, skill_name: str, input_params: Dict[str, Any]) -> Dict[str, Any]:
        """Simulate travel planning skill execution."""
        
        if skill_name == "search_cheap_flights":
            # Simulate finding cheap flights from Tbilisi to Madrid
            return {
                "flights": [
                    {"airline": "Pegasus Airlines", "price": 280, "departure": "2026-12-01 06:00", "stops": 1},
                    {"airline": "Turkish Airlines", "price": 320, "departure": "2026-12-01 10:00", "stops": 1},
                    {"airline": "LOT Polish Airlines", "price:": 350, "departure": "2026-12-01 08:00", "stops": 1},
                    {"airline": "Air Europa", "price": 400, "departure": "2026-12-01 14:00", "stops": 0}
                ],
                "cheapest_option": {"airline": "Pegasus Airlines", "price": 280, "departure": "2026-12-01 06:00", "stops": 1},
                "recommendation": "Pegasus Airlines offers the cheapest option at $280 with one stop via Istanbul"
            }
        
        elif skill_name == "search_budget_hotels":
            # Simulate finding budget hotels near Nebrija University
            daily_budget = input_params.get("daily_budget", 40)
            return {
                "hotels": [
                    {"name": "Hostal Central Madrid", "price": 35, "rating": 4.0, "distance_to_university": "2.5 km"},
                    {"name": "Hotel Europa", "price": 42, "rating": 4.2, "distance_to_university": "1.8 km"},
                    {"name": "Hostal Santiago", "price": 38, "rating": 3.8, "distance_to_university": "3.0 km"},
                    {"name": "Ibis Budget Madrid", "price": 45, "rating": 4.1, "distance_to_university": "2.0 km"}
                ],
                "best_budget_option": {"name": "Hostal Central Madrid", "price": 35, "rating": 4.0, "distance_to_university": "2.5 km"},
                "total_cost": 35 * 7,  # 7 days
                "within_budget": 35 <= daily_budget
            }
        
        elif skill_name == "research_nebrija_university":
            # Simulate research about Nebrija University
            return {
                "university_info": {
                    "name": "Nebrija University",
                    "campuses": ["Madrid - La Berzosa", "Madrid - Dehesa de la Villa", "Madrid - Santa Cruz"],
                    "nearest_campus_to_center": "Madrid - Dehesa de la Villa",
                    "areas_nearby": ["Moncloa", "Ciudad Universitaria", "Chamberí"],
                    "transportation": "Metro: Line 6 (Ciudad Universitaria), Line 7 (Guerra del Río)"
                },
                "accommodation_recommendations": [
                    "Look for hotels in Moncloa or Chamberí areas for easy access",
                    "Hostal Central Madrid is well-connected via public transport",
                    "Consider proximity to Metro Line 6 for university access"
                ]
            }
        
        elif skill_name == "calculate_total_trip_cost":
            flight_cost = input_params.get("flight_cost", 0)
            hotel_cost = input_params.get("hotel_cost", 0)
            daily_budget = input_params.get("daily_budget", 40)
            days = input_params.get("days", 7)
            
            total = flight_cost + hotel_cost
            return {
                "flight_cost": flight_cost,
                "hotel_cost": hotel_cost,
                "daily_budget": daily_budget,
                "days": days,
                "total_cost": total,
                "average_daily_cost": total / days,
                "budget_analysis": {
                    "hotel_within_budget": hotel_cost / days <= daily_budget,
                    "total_reasonable": total < 800  # Reasonable total for 1-week trip
                }
            }
        
        elif skill_name == "create_itinerary":
            return {
                "itinerary": {
                    "day_1": "Arrival, check-in, rest",
                    "day_2": "Visit Nebrija University campus, meet grandson",
                    "day_3": "Explore Madrid center (Puerta del Sol, Plaza Mayor)",
                    "day_4": "Museum visit (Prado or Reina Sofia)",
                    "day_5": "Retiro Park, family time",
                    "day_6": "Local markets, shopping with grandson",
                    "day_7": "Departure"
                },
                "tips": [
                    "Get Madrid Tourist Pass for discounts",
                    "Use Metro for cheapest transportation",
                    "Eat at local cafeterias for budget meals"
                ]
            }
        
        return {"error": "Unknown skill"}

    def create_human_gate(self, gate_type: GateType, question: str, context_data: Dict[str, Any]) -> HumanGate:
        """Create human gate for travel decisions."""
        print(f"\n🚦 Creating human gate: {gate_type.value}")
        print(f"  Question: {question}")
        
        human_gate = HumanGate(
            loop_run_id=self.current_loop_run.id if self.current_loop_run else None,
            gate_type=gate_type,
            question=question,
            context_data=context_data,
            created_at=datetime.now()
        )
        
        print(f"  Context: {context_data}")
        print(f"  ⏳ Waiting for human response...")
        
        # Simulate human approval for demo
        human_gate.decision = GateDecision.APPROVED
        human_gate.human_response = "Approved - proceed with booking"
        human_gate.responded_at = datetime.now()
        human_gate.responder_id = "user_123"
        
        print(f"✓ Human gate resolved: {human_gate.decision.value}")
        
        self.human_gates.append(human_gate)
        return human_gate

    def update_state(self, key: str, value: str, state_type: StateType = StateType.STRING, persists: bool = True) -> LoopState:
        """Update travel planning state."""
        print(f"\n💾 Updating state: {key} = {value}")
        
        loop_state = LoopState(
            state_key=key,
            state_value=value,
            state_type=state_type,
            updated_at=datetime.now(),
            persists_across_runs=persists
        )
        
        self.loop_states[key] = loop_state
        print(f"✓ State updated: {key} ({state_type.value})")
        
        return loop_state

    def create_checkpoint(self, checkpoint_name: str, snapshot_data: Dict[str, Any]):
        """Create checkpoint for travel planning recovery."""
        print(f"\n📸 Creating checkpoint: {checkpoint_name}")
        
        if self.current_loop_run:
            if not self.current_loop_run.checkpoint_data:
                self.current_loop_run.checkpoint_data = {}
            
            self.current_loop_run.checkpoint_data[checkpoint_name] = {
                "timestamp": datetime.now().isoformat(),
                "snapshot": snapshot_data,
                "skill_executions": len(self.skill_executions),
                "human_gates": len(self.human_gates)
            }
        
        print(f"✓ Checkpoint {checkpoint_name} created")

    def complete_loop_run(self, success: bool = True, error_message: Optional[str] = None):
        """Complete the travel planning loop run."""
        if not self.current_loop_run:
            return
        
        self.current_loop_run.completed_at = datetime.now()
        self.current_loop_run.status = LoopRunStatus.COMPLETED if success else LoopRunStatus.FAILED
        self.current_loop_run.error_message = error_message
        
        duration = (self.current_loop_run.completed_at - self.current_loop_run.started_at).total_seconds()
        self.current_loop_run.metrics = {
            "duration_seconds": duration,
            "total_skill_executions": len(self.skill_executions),
            "successful_skills": sum(1 for s in self.skill_executions if s.status == SkillExecutionStatus.COMPLETED),
            "failed_skills": sum(1 for s in self.skill_executions if s.status == SkillExecutionStatus.FAILED),
            "total_human_gates": len(self.human_gates),
            "approved_gates": sum(1 for g in self.human_gates if g.decision == GateDecision.APPROVED),
            "rejected_gates": sum(1 for g in self.human_gates if g.decision == GateDecision.REJECTED),
            "state_updates": len(self.loop_states)
        }
        
        print(f"\n🏁 Travel planning completed")
        print(f"  Status: {self.current_loop_run.status.value}")
        print(f"  Duration: {duration:.2f}s")
        print(f"  Skills executed: {len(self.skill_executions)}")
        print(f"  Human gates: {len(self.human_gates)}")


def main():
    """Demonstrate the Tbilisi to Madrid travel planning."""
    
    print("=" * 70)
    print("TBILISI TO MADRID TRAVEL PLANNING AGENT")
    print("=" * 70)
    
    # Initialize the agent
    agent = TbilisiMadridAgent()
    
    # User's specific travel request
    user_request = {
        "origin": "Tbilisi",
        "destination": "Madrid",
        "start_date": "2026-12-01",
        "end_date": "2026-12-08",
        "daily_budget": 40,
        "purpose": "Visit grandson at Nebrija University"
    }
    
    # Step 1: Start the travel planning process
    loop_run = agent.start_travel_planning(user_request)
    
    # Step 2: Update initial state
    agent.update_state("origin", user_request["origin"])
    agent.update_state("destination", user_request["destination"])
    agent.update_state("daily_budget", str(user_request["daily_budget"]), StateType.NUMBER)
    agent.update_state("purpose", user_request["purpose"])
    
    # Create initial checkpoint
    agent.create_checkpoint("initial_request", {
        "user_request": user_request,
        "state": {k: s.state_value for k, s in agent.loop_states.items()}
    })
    
    # Step 3: Research Nebrija University location
    university_info = agent.execute_skill("research_nebrija_university", {})
    
    # Step 4: Search for cheap flights
    flight_result = agent.execute_skill("search_cheap_flights", {
        "origin": user_request["origin"],
        "destination": user_request["destination"],
        "date": user_request["start_date"]
    })
    
    # Step 5: Search for budget hotels
    hotel_result = agent.execute_skill("search_budget_hotels", {
        "destination": user_request["destination"],
        "daily_budget": user_request["daily_budget"],
        "days": 7
    })
    
    # Step 6: Calculate total trip cost
    cost_result = agent.execute_skill("calculate_total_trip_cost", {
        "flight_cost": flight_result.output_result["cheapest_option"]["price"],
        "hotel_cost": hotel_result.output_result["total_cost"],
        "daily_budget": user_request["daily_budget"],
        "days": 7
    })
    
    # Step 7: Create human gate for budget approval
    hotel_cost_per_day = hotel_result.output_result["total_cost"] / 7
    if hotel_cost_per_day > user_request["daily_budget"]:
        agent.create_human_gate(
            GateType.APPROVAL,
            f"Hotel cost ${hotel_cost_per_day:.0f}/day exceeds budget ${user_request['daily_budget']}/day. Approve?",
            {
                "hotel_cost_per_day": hotel_cost_per_day,
                "budget": user_request["daily_budget"],
                "over_budget_by": hotel_cost_per_day - user_request["daily_budget"]
            }
        )
    else:
        print(f"✓ Hotel cost ${hotel_cost_per_day}/day is within budget!")
    
    # Step 8: Create travel itinerary
    itinerary = agent.execute_skill("create_itinerary", {
        "destination": user_request["destination"],
        "purpose": user_request["purpose"],
        "days": 7
    })
    
    # Step 9: Update state with final information
    agent.update_state("cheapest_flight", flight_result.output_result["cheapest_option"]["airline"])
    agent.update_state("flight_price", str(flight_result.output_result["cheapest_option"]["price"]), StateType.NUMBER)
    agent.update_state("selected_hotel", hotel_result.output_result["best_budget_option"]["name"])
    agent.update_state("hotel_price_per_day", str(hotel_result.output_result["best_budget_option"]["price"]), StateType.NUMBER)
    agent.update_state("total_cost", str(cost_result.output_result["total_cost"]), StateType.NUMBER)
    
    # Step 10: Create final checkpoint
    agent.create_checkpoint("travel_plan_complete", {
        "flight": flight_result.output_result["cheapest_option"],
        "hotel": hotel_result.output_result["best_budget_option"],
        "cost_breakdown": cost_result.output_result,
        "itinerary": itinerary.output_result,
        "final_state": {k: s.state_value for k, s in agent.loop_states.items()}
    })
    
    # Step 11: Complete the loop run
    agent.complete_loop_run(success=True)
    
    # Print comprehensive results
    print("\n" + "=" * 70)
    print("TRAVEL PLAN SUMMARY")
    print("=" * 70)
    
    print(f"\n✈️ FLIGHT DETAILS:")
    flight = flight_result.output_result["cheapest_option"]
    print(f"  Airline: {flight['airline']}")
    print(f"  Price: ${flight['price']}")
    print(f"  Departure: {flight['departure']}")
    print(f"  Stops: {flight['stops']}")
    print(f"  Recommendation: {flight_result.output_result['recommendation']}")
    
    print(f"\n🏨 HOTEL DETAILS:")
    hotel = hotel_result.output_result["best_budget_option"]
    print(f"  Name: {hotel['name']}")
    print(f"  Price: ${hotel['price']}/day")
    print(f"  Rating: {hotel['rating']}/5")
    print(f"  Distance to Nebrija: {hotel['distance_to_university']}")
    print(f"  Total for 7 days: ${hotel['price'] * 7}")
    
    print(f"\n💰 COST BREAKDOWN:")
    cost = cost_result.output_result
    print(f"  Flight: ${cost['flight_cost']}")
    print(f"  Hotel (7 days): ${cost['hotel_cost']}")
    print(f"  Total: ${cost['total_cost']}")
    print(f"  Average daily: ${cost['average_daily_cost']:.2f}")
    print(f"  Hotel within budget: {'✅' if cost['budget_analysis']['hotel_within_budget'] else '❌'}")
    
    print(f"\n🎓 NEBRIJA UNIVERSITY INFO:")
    uni_info = university_info.output_result["university_info"]
    print(f"  Campuses: {', '.join(uni_info['campuses'])}")
    print(f"  Nearest to center: {uni_info['nearest_campus_to_center']}")
    print(f"  Recommended areas: {', '.join(uni_info['areas_nearby'])}")
    print(f"  Metro access: {uni_info['transportation']}")
    
    print(f"\n📅 SUGGESTED ITINERARY:")
    for day, activity in itinerary.output_result["itinerary"].items():
        print(f"  {day.replace('_', ' ').title()}: {activity}")
    
    print(f"\n💡 TRAVEL TIPS:")
    for tip in itinerary.output_result["tips"]:
        print(f"  • {tip}")
    
    print("\n" + "=" * 70)
    print("This demonstrates how LP's agent-based automation can:")
    print("  • Track complex travel planning workflows")
    print("  • Execute multiple skills (flight search, hotel search, research)")
    print("  • Manage budget constraints and human approvals")
    print("  • Create comprehensive travel plans with state management")
    print("  • Provide checkpoints for recovery and audit trails")
    print("=" * 70)


if __name__ == "__main__":
    main()
