Assume I want to go from Tbilisi to Madrid at the bedinning of Decmber for one week. 
I wish one cheep flite tickets, I need  a flat in hotel at price around $40 per day. 
My trip aim is to see my grangsun who studies in Nebrija unuvercity.
How can I use LP to solve this task?
======================================================================
user@user:/media/user/dsk64/loop-engineering/LP$ python Tbilisi_madrid_agent.py
======================================================================
TBILISI TO MADRID TRAVEL PLANNING AGENT
======================================================================
🚀 Starting Tbilisi to Madrid travel planning...
✓ LoopRun None started
  Origin: Tbilisi
  Destination: Madrid
  Dates: 2026-12-01 to 2026-12-08
  Budget: $40/day for hotel
  Purpose: Visit grandson at Nebrija University

💾 Updating state: origin = Tbilisi
✓ State updated: origin (string)

💾 Updating state: destination = Madrid
✓ State updated: destination (string)

💾 Updating state: daily_budget = 40
✓ State updated: daily_budget (number)

💾 Updating state: purpose = Visit grandson at Nebrija University
✓ State updated: purpose (string)

📸 Creating checkpoint: initial_request
✓ Checkpoint initial_request created

🤖 Executing skill: research_nebrija_university
✓ Skill research_nebrija_university completed in 0ms

🤖 Executing skill: search_cheap_flights
✓ Skill search_cheap_flights completed in 0ms

🤖 Executing skill: search_budget_hotels
✓ Skill search_budget_hotels completed in 0ms

🤖 Executing skill: calculate_total_trip_cost
✓ Skill calculate_total_trip_cost completed in 0ms
✓ Hotel cost $35.0/day is within budget!

🤖 Executing skill: create_itinerary
✓ Skill create_itinerary completed in 0ms

💾 Updating state: cheapest_flight = Pegasus Airlines
✓ State updated: cheapest_flight (string)

💾 Updating state: flight_price = 280
✓ State updated: flight_price (number)

💾 Updating state: selected_hotel = Hostal Central Madrid
✓ State updated: selected_hotel (string)

💾 Updating state: hotel_price_per_day = 35
✓ State updated: hotel_price_per_day (number)

💾 Updating state: total_cost = 525
✓ State updated: total_cost (number)

📸 Creating checkpoint: travel_plan_complete
✓ Checkpoint travel_plan_complete created

🏁 Travel planning completed
  Status: completed
  Duration: 0.00s
  Skills executed: 5
  Human gates: 0

======================================================================
TRAVEL PLAN SUMMARY
======================================================================

✈️ FLIGHT DETAILS:
  Airline: Pegasus Airlines
  Price: $280
  Departure: 2026-12-01 06:00
  Stops: 1
  Recommendation: Pegasus Airlines offers the cheapest option at $280 with one stop via Istanbul

🏨 HOTEL DETAILS:
  Name: Hostal Central Madrid
  Price: $35/day
  Rating: 4.0/5
  Distance to Nebrija: 2.5 km
  Total for 7 days: $245

💰 COST BREAKDOWN:
  Flight: $280
  Hotel (7 days): $245
  Total: $525
  Average daily: $75.00
  Hotel within budget: ✅

🎓 NEBRIJA UNIVERSITY INFO:
  Campuses: Madrid - La Berzosa, Madrid - Dehesa de la Villa, Madrid - Santa Cruz
  Nearest to center: Madrid - Dehesa de la Villa
  Recommended areas: Moncloa, Ciudad Universitaria, Chamberí
  Metro access: Metro: Line 6 (Ciudad Universitaria), Line 7 (Guerra del Río)

📅 SUGGESTED ITINERARY:
  Day 1: Arrival, check-in, rest
  Day 2: Visit Nebrija University campus, meet grandson
  Day 3: Explore Madrid center (Puerta del Sol, Plaza Mayor)
  Day 4: Museum visit (Prado or Reina Sofia)
  Day 5: Retiro Park, family time
  Day 6: Local markets, shopping with grandson
  Day 7: Departure

💡 TRAVEL TIPS:
  • Get Madrid Tourist Pass for discounts
  • Use Metro for cheapest transportation
  • Eat at local cafeterias for budget meals

======================================================================
This demonstrates how LP's agent-based automation can:
  • Track complex travel planning workflows
  • Execute multiple skills (flight search, hotel search, research)
  • Manage budget constraints and human approvals
  • Create comprehensive travel plans with state management
  • Provide checkpoints for recovery and audit trails
======================================================================

