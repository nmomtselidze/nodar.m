# Agent-Based Automation System Examples

This document demonstrates how the LP project's data models (LoopRun, SkillExecution, HumanGate, LoopState) work together to create a comprehensive agent-based automation system.

## Overview

The LP project includes data models for building sophisticated agent-based workflows:

- **LoopRun**: Tracks individual executions of automated workflows
- **SkillExecution**: Monitors individual agent operations/skills
- **HumanGate**: Enables human-in-the-loop approval workflows
- **LoopState**: Manages persistent state across executions
- **Checkpoint**: Provides recovery and audit capabilities

## Example Files

### 1. Simple Loop Example (`example_simple_loop.py`)

A basic demonstration showing the core concepts:

```bash
python example_simple_loop.py
```

**What it demonstrates:**
- Creating and managing a LoopRun
- Executing and tracking a SkillExecution
- Creating a HumanGate for approval
- Updating persistent LoopState
- Completing the run with metrics

**Use case:** Data synchronization workflow with validation and human approval

### 2. Travel Booking Agent (`example_travel_agent.py`)

A comprehensive example showing a real-world agent workflow:

```bash
python example_travel_agent.py
```

**What it demonstrates:**
- Complete travel booking workflow
- Multiple skill executions (flight search, hotel search, booking)
- Human approval gates for budget overruns
- State management across the workflow
- Checkpoint creation for recovery
- Comprehensive execution metrics

**Use case:** Travel booking agent that searches, validates, gets approval, and books

## Key Concepts

### LoopRun - The Execution Context

LoopRun provides the overall context for an automated workflow:

```python
loop_run = LoopRun(
    started_at=datetime.now(),
    status=LoopRunStatus.RUNNING,
    trigger_type=TriggerType.MANUAL,
    trigger_metadata={"user_request": request_data}
)
```

**Benefits:**
- Tracks when executions start/complete
- Records what triggered the workflow
- Captures overall success/failure status
- Provides metrics for monitoring
- Enables audit trails

### SkillExecution - Individual Operations

Each agent operation is tracked as a SkillExecution:

```python
skill = SkillExecution(
    loop_run_id=loop_run.id,
    skill_name="search_flights",
    started_at=datetime.now(),
    input_params={"destination": "Paris", "date": "2026-10-01"}
)
```

**Benefits:**
- Monitors individual skill performance
- Tracks execution time and token usage
- Captures input/output for debugging
- Provides error context when failures occur
- Enables performance optimization

### HumanGate - Human-in-the-Loop

Human gates enable approval workflows and human input:

```python
gate = HumanGate(
    loop_run_id=loop_run.id,
    gate_type=GateType.APPROVAL,
    question="Total cost $1960 exceeds budget. Approve?",
    context_data={"cost": 1960, "budget": 1000}
)
```

**Benefits:**
- Enables human oversight of automated decisions
- Provides context for informed decisions
- Records decision rationale
- Supports multiple gate types (approval, confirmation, input)
- Maintains audit trail of human interventions

### LoopState - Persistent State

State that persists across loop executions:

```python
state = LoopState(
    state_key="api_token",
    state_value="secret_token_123",
    state_type=StateType.STRING,
    persists_across_runs=True
)
```

**Benefits:**
- Maintains configuration across executions
- Enables recovery from failures
- Supports incremental processing
- Provides context for subsequent runs
- Avoids redundant computations

### Checkpoint - Recovery Points

Snapshots of execution state for recovery:

```python
loop_run.checkpoint_data = {
    "pre_booking": {
        "timestamp": datetime.now().isoformat(),
        "snapshot": current_state,
        "skill_executions": len(skill_executions)
    }
}
```

**Benefits:**
- Enables recovery from failures
- Supports resume functionality
- Provides audit checkpoints
- Facilitates debugging
- Enables rollback capabilities

## Real-World Use Cases

### 1. Data Pipeline Orchestration

```python
# LoopRun tracks the entire ETL pipeline
# SkillExecutions monitor each extraction/transformation/load step
# HumanGates provide approval for schema changes
# LoopState maintains connection credentials and offsets
# Checkpoints enable recovery from mid-pipeline failures
```

### 2. DevOps Automation

```python
# LoopRun tracks deployment execution
# SkillExecutions monitor build, test, deploy steps
# HumanGates provide approval for production deployments
# LoopState maintains deployment history and rollback points
# Checkpoints enable rollback to previous stable state
```

### 3. Customer Service Automation

```python
# LoopRun tracks customer issue resolution
# SkillExecutions monitor each automated response step
# HumanGates escalate complex issues to human agents
# LoopState maintains customer context and history
# Checkpoints enable resuming interrupted conversations
```

### 4. Financial Processing

```python
# LoopRun tracks transaction processing
# SkillExecutions monitor validation, compliance, settlement
# HumanGates provide approval for large transactions
# LoopState maintains compliance flags and audit trails
# Checkpoints enable recovery from processing failures
```

## Integration with Current LP Task Manager

The current LP CLI focuses on basic task management, but the data models are designed to support:

1. **Enhanced Task Processing**: Tasks could be processed by agent loops
2. **Automated Workflows**: Task completion could trigger skill executions
3. **Human Approval**: Important task changes could require human gates
4. **State Management**: Task configurations could persist across runs
5. **Recovery**: Failed task processing could use checkpoints for recovery

## Running the Examples

```bash
# Simple example
cd /media/user/dsk64/loop-engineering/LP
python example_simple_loop.py

# Travel booking agent
python example_travel_agent.py
```

## Future Development

To extend the current LP task manager into a full agent system:

1. **Add LoopRun CLI commands** for managing workflow executions
2. **Integrate skill execution** with task processing
3. **Add human gate UI** for approval workflows
4. **Implement state persistence** in the database
5. **Add checkpoint management** for recovery
6. **Create agent templates** for common workflows

## Conclusion

These examples demonstrate how the LP project's data models provide a foundation for building sophisticated agent-based automation systems. The models work together to provide:

- **Observability**: Complete tracking of automated workflows
- **Reliability**: Checkpoints and recovery mechanisms
- **Control**: Human-in-the-loop approval processes
- **Statefulness**: Persistent context across executions
- **Auditability**: Comprehensive logs and metrics

The current task manager is a starting point that could evolve into a full agent-based automation platform using these foundational models.