"""
Simple Loop Run Example
A basic demonstration of how LoopRun, SkillExecution, and related models work together.
"""

from datetime import datetime
from src.task_manager.models import (
    LoopRun, LoopRunStatus, TriggerType,
    SkillExecution, SkillExecutionStatus,
    HumanGate, GateType, GateDecision,
    LoopState, StateType
)


def simple_loop_example():
    """Demonstrate basic loop run functionality."""
    
    print("🔄 Simple Loop Run Example")
    print("=" * 50)
    
    # 1. Create a new loop run
    print("\n1. Starting Loop Run")
    loop_run = LoopRun(
        started_at=datetime.now(),
        status=LoopRunStatus.RUNNING,
        trigger_type=TriggerType.MANUAL,
        trigger_metadata={"user": "admin", "action": "data_sync"}
    )
    print(f"   LoopRun ID: {loop_run.id}")
    print(f"   Status: {loop_run.status.value}")
    print(f"   Trigger: {loop_run.trigger_type.value}")
    
    # 2. Execute a skill
    print("\n2. Executing Skill")
    skill = SkillExecution(
        loop_run_id=loop_run.id,
        skill_name="data_validation",
        started_at=datetime.now(),
        status=SkillExecutionStatus.RUNNING,
        input_params={"data_source": "api", "record_count": 1000}
    )
    
    # Simulate skill completion
    skill.status = SkillExecutionStatus.COMPLETED
    skill.completed_at = datetime.now()
    skill.output_result = {"valid_records": 950, "invalid_records": 50}
    skill.execution_time_ms = 250
    
    print(f"   Skill: {skill.skill_name}")
    print(f"   Status: {skill.status.value}")
    print(f"   Execution time: {skill.execution_time_ms}ms")
    print(f"   Result: {skill.output_result}")
    
    # 3. Create a human gate
    print("\n3. Creating Human Gate")
    gate = HumanGate(
        loop_run_id=loop_run.id,
        gate_type=GateType.CONFIRMATION,
        question="50 invalid records found. Continue processing?",
        context_data={"invalid_count": 50, "total_count": 1000}
    )
    
    # Simulate human response
    gate.decision = GateDecision.APPROVED
    gate.human_response = "Yes, continue with valid records"
    gate.responded_at = datetime.now()
    
    print(f"   Gate Type: {gate.gate_type.value}")
    print(f"   Question: {gate.question}")
    print(f"   Decision: {gate.decision.value}")
    print(f"   Response: {gate.human_response}")
    
    # 4. Update loop state
    print("\n4. Updating Loop State")
    state = LoopState(
        state_key="last_sync_time",
        state_value=datetime.now().isoformat(),
        state_type=StateType.STRING,
        persists_across_runs=True
    )
    
    print(f"   Key: {state.state_key}")
    print(f"   Value: {state.state_value}")
    print(f"   Type: {state.state_type.value}")
    print(f"   Persists: {state.persists_across_runs}")
    
    # 5. Complete the loop run
    print("\n5. Completing Loop Run")
    loop_run.completed_at = datetime.now()
    loop_run.status = LoopRunStatus.COMPLETED
    loop_run.tasks_processed = 1
    loop_run.tasks_created = 0
    loop_run.tasks_updated = 0
    loop_run.tasks_deleted = 0
    
    duration = (loop_run.completed_at - loop_run.started_at).total_seconds()
    loop_run.metrics = {
        "duration_seconds": duration,
        "skills_executed": 1,
        "human_gates": 1,
        "state_updates": 1
    }
    
    print(f"   Final Status: {loop_run.status.value}")
    print(f"   Duration: {duration:.2f}s")
    print(f"   Metrics: {loop_run.metrics}")
    
    # 6. Show relationships
    print("\n6. Model Relationships")
    print(f"   LoopRun → SkillExecution: {loop_run.id} → {skill.loop_run_id}")
    print(f"   LoopRun → HumanGate: {loop_run.id} → {gate.loop_run_id}")
    print(f"   LoopState: Persists across runs = {state.persists_across_runs}")
    
    print("\n" + "=" * 50)
    print("✅ Example completed successfully!")
    print("\nKey Benefits Demonstrated:")
    print("  • Execution tracking with LoopRun")
    print("  • Skill monitoring with SkillExecution") 
    print("  • Human-in-the-loop with HumanGate")
    print("  • Persistent state with LoopState")
    print("  • Complete audit trail and metrics")


if __name__ == "__main__":
    simple_loop_example()