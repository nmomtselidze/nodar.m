# LP (Loop Engineering) Calling Schema

## Architecture Overview

LP is a multi-layered system consisting of task management and agent-based automation capabilities. The calling schema shows how components interact across different layers.

```
┌─────────────────────────────────────────────────────────────────────┐
│                        USER INTERFACE LAYER                        │
├─────────────────────────────────────────────────────────────────────┤
│  Makefile Commands │  Custom Agent Scripts │  Direct CLI Usage    │
│  (make add, list) │  (travel_agent.py)   │  (python -m src...)  │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│                          CLI LAYER                                   │
├─────────────────────────────────────────────────────────────────────┤
│  cli.py (argparse-based command interface)                          │
│  ┌──────────────┬──────────────┬──────────────┬──────────────┐    │
│  │ cmd_add()    │ cmd_list()   │ cmd_update() │ cmd_status() │    │
│  │ cmd_show()   │ cmd_delete() │ cmd_search() │ cmd_complete │    │
│  └──────────────┴──────────────┴──────────────┴──────────────┘    │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│                        SERVICE LAYER                                 │
├─────────────────────────────────────────────────────────────────────┤
│  service.py (TaskService - Business Logic Layer)                    │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  TaskService                                                 │  │
│  │  ├── create_task()      → Database.add_task()               │  │
│  │  ├── get_task()         → Database.get_task()               │  │
│  │  ├── list_all_tasks()   → Database.get_all_tasks()         │  │
│  │  ├── update_task_status() → Database.update_task()         │  │
│  │  ├── update_task_priority() → Database.update_task()        │  │
│  │  ├── update_task_details() → Database.update_task()         │  │
│  │  ├── delete_task()      → Database.delete_task()            │  │
│  │  ├── search_tasks()     → Local filtering                  │  │
│  │  └── clear_all_tasks()  → Database.clear_all_tasks()       │  │
│  └──────────────────────────────────────────────────────────────┘  │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      DATA LAYER                                      │
├─────────────────────────────────────────────────────────────────────┤
│  database.py (Database - SQLite Operations)                          │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  Database                                                     │  │
│  │  ├── add_task()          → INSERT INTO tasks                  │  │
│  │  ├── get_task()          → SELECT FROM tasks WHERE id=?       │  │
│  │  ├── get_all_tasks()    → SELECT * FROM tasks                │  │
│  │  ├── get_tasks_by_status() → SELECT * FROM tasks WHERE status│  │
│  │  ├── get_tasks_by_priority() → SELECT * FROM tasks WHERE     │  │
│  │  ├── update_task()      → UPDATE tasks SET ... WHERE id=?     │  │
│  │  ├── delete_task()      → DELETE FROM tasks WHERE id=?       │  │
│  │  └── clear_all_tasks()  → DELETE FROM tasks                  │  │
│  └──────────────────────────────────────────────────────────────┘  │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    STORAGE LAYER                                     │
├─────────────────────────────────────────────────────────────────────┤
│  SQLite Database (tasks.db)                                         │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  Table: tasks                                                 │  │
│  │  ├── id (INTEGER PRIMARY KEY)                                 │  │
│  │  ├── title (TEXT)                                             │  │
│  │  ├── description (TEXT)                                       │  │
│  │  ├── status (TEXT)                                            │  │
│  │  ├── priority (TEXT)                                          │  │
│  │  ├── created_at (TEXT)                                        │  │
│  │  ├── updated_at (TEXT)                                        │  │
│  │  └── due_date (TEXT)                                          │  │
│  └──────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
```

## Agent-Based Automation Layer

LP also includes an agent-based automation system that operates independently but uses the same data models:

```
┌─────────────────────────────────────────────────────────────────────┐
│                 AGENT AUTOMATION LAYER                                │
├─────────────────────────────────────────────────────────────────────┤
│  Custom Agent Scripts (e.g., tbilisi_madrid_agent.py)                │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  TravelBookingAgent / TbilisiMadridAgent                     │  │
│  │  ├── start_booking_process() → LoopRun creation              │  │
│  │  ├── execute_skill() → SkillExecution tracking                │  │
│  │  ├── create_human_gate() → HumanGate for approvals            │  │
│  │  ├── update_state() → LoopState management                    │  │
│  │  ├── create_checkpoint() → Recovery points                    │  │
│  │  └── complete_loop_run() → Final metrics & status              │  │
│  └──────────────────────────────────────────────────────────────┘  │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    MODELS LAYER (Shared)                             │
├─────────────────────────────────────────────────────────────────────┤
│  models.py (Data Models & Enums)                                     │
│  ┌──────────────────┬──────────────────┬──────────────────┐         │
│  │ Task Models      │ Automation Models │ Travel Models     │         │
│  │                  │                  │                  │         │
│  │ • Task           │ • LoopRun        │ • Trip           │         │
│  │ • TaskStatus     │ • SkillExecution │ • Booking        │         │
│  │ • TaskPriority   │ • HumanGate      │ • Activity       │         │
│  │                  │ • LoopState      │ • Agent          │         │
│  │                  │ • Checkpoint     │                  │         │
│  └──────────────────┴──────────────────┴──────────────────┘         │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  Enums:                                                       │  │
│  │  • TaskStatus, TaskPriority                                   │  │
│  │  • LoopRunStatus, TriggerType                                  │  │
│  │  • SkillExecutionStatus, GateType, GateDecision               │  │
│  │  • StateType, BookingStatus, BookingType                       │  │
│  │  • AgentStatus, TripStatus                                     │  │
│  └──────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
```

## Detailed Call Flow Diagrams

### 1. Task Creation Flow

```
User Command: make add TITLE="Task" DESC="Description" PRIORITY=high
                     │
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Makefile                                                            │
│ add:                                                                │
│   $(CLI) add "$(TITLE)" -d "$(DESC)" -p $(PRIORITY)                 │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│ CLI: cmd_add()                                                      │
│ • Parse arguments (title, description, priority, due_date)          │
│ • Call TaskService.create_task()                                    │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Service: TaskService.create_task()                                  │
│ • Create Task object with provided parameters                       │
│ • Call Database.add_task(task)                                      │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Database: Database.add_task()                                       │
│ • INSERT INTO tasks (title, description, status, priority, ...)     │
│ • Execute SQL query                                                 │
│ • Return Task with generated ID                                     │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│ SQLite: tasks.db                                                    │
│ • Persist task data                                                 │
│ • Auto-generate ID                                                  │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
           Return Task object to user
```

### 2. Task Listing Flow

```
User Command: make list FLAGS="-s pending"
                    │
                                 ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Makefile                                                            │
│ list:                                                               │
│   $(CLI) list $(FLAGS)                                              │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│ CLI: cmd_list()                                                     │
│ • Parse filter flags (status, priority)                             │
│ • Call appropriate TaskService method                               │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Service: TaskService.list_tasks_by_status()                         │
│ • Call Database.get_tasks_by_status(status)                         │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Database: Database.get_tasks_by_status()                            │
│ • SELECT * FROM tasks WHERE status = ?                              │
│ • Execute SQL query with parameter binding                          │
│ • Return list of Task objects                                       │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│ SQLite: tasks.db                                                    │
│ • Query tasks table                                                 │
│ • Filter by status                                                  │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
           Return filtered Task list to user
```

### 3. Agent Automation Flow

```
User Script: python tbilisi_madrid_agent.py
         │
               ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Agent: TbilisiMadridAgent.start_travel_planning()                   │
│ • Create LoopRun object                                             │
│ • Set status to RUNNING, trigger to MANUAL                          │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Agent: execute_skill("search_cheap_flights", params)                │
│ • Create SkillExecution object                                      │
│ • Set status to RUNNING                                             │
│ • Call _simulate_skill_execution()                                  │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Agent: _simulate_skill_execution()                                  │
│ • Process skill-specific logic                                      │
│ • Return flight/hotel/search results                                │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Agent: Update SkillExecution                                        │
│ • Set status to COMPLETED                                           │
│ • Store output_result and execution_time_ms                         │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Agent: create_human_gate()                                          │
│ • Create HumanGate object for approval workflow                     │
│ • Set question and context_data                                     │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Agent: update_state()                                               │
│ • Create LoopState object                                           │
│ • Store key-value pairs for persistence                             │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Agent: create_checkpoint()                                          │
│ • Store snapshot_data in LoopRun.checkpoint_data                    │
│ • Enable recovery from failures                                     │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Agent: complete_loop_run()                                          │
│ • Set LoopRun status to COMPLETED                                   │
│ • Calculate final metrics (duration, skill counts, etc.)            │
└────────────────────┬────────────────────────────────────────────────┘
                     │
                                   ▼
           Return execution summary to user
```

## Component Relationships

### Model Hierarchy

```
models.py
├── Enums
│   ├── TaskStatus, TaskPriority
│   ├── LoopRunStatus, TriggerType
│   ├── SkillExecutionStatus
│   ├── GateType, GateDecision
│   ├── StateType
│   ├── BookingStatus, BookingType
│   ├── AgentStatus, TripStatus
│
├── Task Management Models
│   └── Task (id, title, description, status, priority, created_at, updated_at, due_date)
│
├── Automation Models
│   ├── LoopRun (id, started_at, completed_at, status, trigger_type, metrics, checkpoint_data)
│   ├── SkillExecution (id, loop_run_id, skill_name, status, input_params, output_result)
│   ├── HumanGate (id, loop_run_id, gate_type, question, decision, human_response)
│   ├── LoopState (id, state_key, state_value, state_type, persists_across_runs)
│   └── Checkpoint (id, checkpoint_name, loop_run_id, snapshot_data)
│
└── Travel Domain Models
    ├── Trip (id, destination, start_date, end_date, budget, travelers, status)
    ├── Booking (id, trip_id, booking_type, status, provider, cost, confirmation_code)
    ├── Activity (id, trip_id, name, location, date, duration_hours, cost)
    └── Agent (id, agent_type, status, current_task, capabilities)
```

### Service Layer Dependencies

```
TaskService
├── Depends on: Database
├── Uses: Task, TaskStatus, TaskPriority models
└── Provides: Business logic for task operations

Database
├── Depends on: SQLite3
├── Uses: Task model
└── Provides: Data persistence operations
```

### Agent System Dependencies

```
Custom Agents (e.g., TravelBookingAgent)
├── Depends on: models.py (all automation models)
├── Uses: LoopRun, SkillExecution, HumanGate, LoopState
└── Provides: Domain-specific automation workflows
```

## Data Flow Summary

### Task Management Data Flow
```
User Input → CLI Parser → TaskService → Database → SQLite → Return Result
```

### Agent Automation Data Flow
```
User Script → Agent Class → Model Creation → Skill Execution → State Management → Checkpoint → Completion
```

### Cross-Layer Data Flow
```
Models (Shared) ←→ Task Management System
Models (Shared) ←→ Agent Automation System
```

## Key Design Patterns

1. **Layered Architecture**: Clear separation between UI, business logic, and data layers
2. **Service Layer Pattern**: TaskService encapsulates business logic
3. **Data Access Object Pattern**: Database class handles all SQLite operations
4. **Model-View Separation**: Models defined separately from business logic
5. **Agent Pattern**: Custom agents implement domain-specific automation workflows
6. **State Management**: LoopState provides persistent state across executions
7. **Checkpoint Pattern**: Enables recovery and audit trails in automation workflows

## Integration Points

1. **CLI → Service**: Direct method calls for task operations
2. **Service → Database**: Method calls for data persistence
3. **Database → SQLite**: SQL query execution
4. **Agents → Models**: Direct model instantiation and manipulation
5. **Custom Scripts → Agents**: Instantiation and method calls
6. **Shared Models**: Both task management and agent systems use the same model definitions

This calling schema demonstrates LP's modular design, where task management and agent-based automation coexist while sharing common data models and following clear architectural patterns.
