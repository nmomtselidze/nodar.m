//Loop Engineering: A Crash Course
https://agentfactory.panaversity.org/docs/loop-engineering-crash-course

//Start test.html
Linux: xdg-open test.html

Using a graphical explorer
Go to the folder: /media/user/dsk64/loop-engineering 
through a regular file manager and double-click on the file test.html.
#=================================================================
cd /media/user/dsk64/loop-engineering/LP
user@user:/media/user/dsk64/loop-engineering/LP$ python tbilisi_madrid_agent.py
or
user@user:/media/user/dsk64/loop-engineering/LP$ uv run python tbilisi_madrid_agent.py
