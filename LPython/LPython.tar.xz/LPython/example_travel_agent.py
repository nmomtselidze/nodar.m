"""
Example: Travel Booking Agent System
Demonstrates how LoopRun, SkillExecution, HumanGate, and LoopState work together
in an agent-based automation system.
"""

from datetime import datetime, timedelta
from typing import Dict, Any, Optional
from src.task_manager.models import (
    LoopRun, LoopRunStatus, TriggerType,
    SkillExecution, SkillExecutionStatus,
    HumanGate, GateType, GateDecision,
    LoopState, StateType,
    Trip, TripStatus, Booking, BookingType, BookingStatus, Agent, AgentStatus
)


class TravelBookingAgent:
    """
    A travel booking agent that demonstrates the full agent-based automation system.
    This agent handles trip planning, booking, and human approval workflows.
    """

    def __init__(self):
        self.current_loop_run: Optional[LoopRun] = None
        self.skill_executions: list[SkillExecution] = []
        self.human_gates: list[HumanGate] = []
        self.loop_states: dict[str, LoopState] = {}
        self.agents: dict[str, Agent] = {}

    def start_booking_process(self, user_request: Dict[str, Any]) -> LoopRun:
        """
        Start a new loop run for travel booking process.
        This creates the execution context for the entire workflow.
        """
        print("🚀 Starting travel booking process...")
        
        # Create a new LoopRun to track this execution
        self.current_loop_run = LoopRun(
            started_at=datetime.now(),
            status=LoopRunStatus.RUNNING,
            trigger_type=TriggerType.MANUAL,
            trigger_metadata={"user_request": user_request},
            tasks_processed=0,
            tasks_created=0,
            tasks_updated=0,
            tasks_deleted=0
        )
        
        print(f"✓ LoopRun {self.current_loop_run.id} started")
        print(f"  Trigger: {self.current_loop_run.trigger_type.value}")
        print(f"  User request: {user_request}")
        
        return self.current_loop_run

    def execute_skill(self, skill_name: str, input_params: Dict[str, Any]) -> SkillExecution:
        """
        Execute a skill (agent operation) and track its execution.
        This represents individual operations within the loop.
        """
        print(f"\n🤖 Executing skill: {skill_name}")
        
        skill_execution = SkillExecution(
            loop_run_id=self.current_loop_run.id if self.current_loop_run else None,
            skill_name=skill_name,
            started_at=datetime.now(),
            status=SkillExecutionStatus.RUNNING,
            input_params=input_params
        )
        
        # Simulate skill execution
        try:
            # This would call the actual skill/agent
            result = self._simulate_skill_execution(skill_name, input_params)
            
            skill_execution.status = SkillExecutionStatus.COMPLETED
            skill_execution.completed_at = datetime.now()
            skill_execution.output_result = result
            skill_execution.execution_time_ms = int(
                (skill_execution.completed_at - skill_execution.started_at).total_seconds() * 1000
            )
            skill_execution.token_usage = len(str(result))  # Simulate token usage
            
            print(f"✓ Skill {skill_name} completed in {skill_execution.execution_time_ms}ms")
            
        except Exception as e:
            skill_execution.status = SkillExecutionStatus.FAILED
            skill_execution.completed_at = datetime.now()
            skill_execution.error_message = str(e)
            print(f"✗ Skill {skill_name} failed: {e}")
        
        self.skill_executions.append(skill_execution)
        
        # Update loop run metrics
        if self.current_loop_run:
            self.current_loop_run.tasks_processed += 1
        
        return skill_execution

    def _simulate_skill_execution(self, skill_name: str, input_params: Dict[str, Any]) -> Dict[str, Any]:
        """Simulate actual skill execution for demonstration purposes."""
        
        if skill_name == "search_flights":
            return {
                "flights": [
                    {"airline": "Delta", "price": 450, "departure": "2026-10-01 10:00"},
                    {"airline": "United", "price": 380, "departure": "2026-10-01 14:00"},
                    {"airline": "American", "price": 420, "departure": "2026-10-01 08:00"}
                ],
                "best_option": {"airline": "United", "price": 380, "departure": "2026-10-01 14:00"}
            }
        
        elif skill_name == "search_hotels":
            return {
                "hotels": [
                    {"name": "Marriott", "price": 180, "rating": 4.5},
                    {"name": "Hilton", "price": 150, "rating": 4.2},
                    {"name": "Hyatt", "price": 200, "rating": 4.7}
                ],
                "best_option": {"name": "Hyatt", "price": 200, "rating": 4.7}
            }
        
        elif skill_name == "calculate_total_cost":
            flight_cost = input_params.get("flight_cost", 0)
            hotel_cost = input_params.get("hotel_cost", 0)
            total = flight_cost + hotel_cost
            return {
                "flight_cost": flight_cost,
                "hotel_cost": hotel_cost,
                "total_cost": total,
                "within_budget": total <= input_params.get("budget", float('inf'))
            }
        
        elif skill_name == "create_booking":
            booking_type = input_params.get("booking_type", "flight")
            return {
                "booking_id": f"BK{datetime.now().strftime('%Y%m%d%H%M%S')}",
                "confirmation_code": f"CONF{booking_type.upper()}{hash(str(input_params)) % 10000:04d}",
                "status": "confirmed",
                "provider": input_params.get("provider", "Unknown")
            }
        
        return {"error": "Unknown skill"}

    def create_human_gate(self, gate_type: GateType, question: str, context_data: Dict[str, Any]) -> HumanGate:
        """
        Create a human gate for approval/input in the workflow.
        This enables human-in-the-loop processes.
        """
        print(f"\n🚦 Creating human gate: {gate_type.value}")
        print(f"  Question: {question}")
        
        human_gate = HumanGate(
            loop_run_id=self.current_loop_run.id if self.current_loop_run else None,
            gate_type=gate_type,
            question=question,
            context_data=context_data,
            created_at=datetime.now()
        )
        
        # Simulate human response (in real system, this would wait for actual human input)
        print(f"  Context: {context_data}")
        print(f"  ⏳ Waiting for human response...")
        
        # Simulate human approval for demo
        human_gate.decision = GateDecision.APPROVED
        human_gate.human_response = "Approved - looks good!"
        human_gate.responded_at = datetime.now()
        human_gate.responder_id = "user_123"
        
        print(f"✓ Human gate resolved: {human_gate.decision.value}")
        
        self.human_gates.append(human_gate)
        return human_gate

    def update_state(self, key: str, value: str, state_type: StateType = StateType.STRING, persists: bool = True) -> LoopState:
        """
        Update loop state that can persist across runs.
        This enables stateful workflows and recovery.
        """
        print(f"\n💾 Updating state: {key} = {value}")
        
        loop_state = LoopState(
            state_key=key,
            state_value=value,
            state_type=state_type,
            updated_at=datetime.now(),
            persists_across_runs=persists
        )
        
        self.loop_states[key] = loop_state
        print(f"✓ State updated: {key} ({state_type.value})")
        
        return loop_state

    def get_state(self, key: str) -> Optional[LoopState]:
        """Retrieve current state value."""
        return self.loop_states.get(key)

    def create_checkpoint(self, checkpoint_name: str, snapshot_data: Dict[str, Any]):
        """
        Create a checkpoint for recovery purposes.
        This enables resuming from failures.
        """
        print(f"\n📸 Creating checkpoint: {checkpoint_name}")
        
        if self.current_loop_run:
            if not self.current_loop_run.checkpoint_data:
                self.current_loop_run.checkpoint_data = {}
            
            self.current_loop_run.checkpoint_data[checkpoint_name] = {
                "timestamp": datetime.now().isoformat(),
                "snapshot": snapshot_data,
                "skill_executions": len(self.skill_executions),
                "human_gates": len(self.human_gates)
            }
        
        print(f"✓ Checkpoint {checkpoint_name} created")

    def complete_loop_run(self, success: bool = True, error_message: Optional[str] = None):
        """
        Complete the loop run with final status and metrics.
        This provides execution summary and audit trail.
        """
        if not self.current_loop_run:
            return
        
        self.current_loop_run.completed_at = datetime.now()
        self.current_loop_run.status = LoopRunStatus.COMPLETED if success else LoopRunStatus.FAILED
        self.current_loop_run.error_message = error_message
        
        # Calculate final metrics
        duration = (self.current_loop_run.completed_at - self.current_loop_run.started_at).total_seconds()
        self.current_loop_run.metrics = {
            "duration_seconds": duration,
            "total_skill_executions": len(self.skill_executions),
            "successful_skills": sum(1 for s in self.skill_executions if s.status == SkillExecutionStatus.COMPLETED),
            "failed_skills": sum(1 for s in self.skill_executions if s.status == SkillExecutionStatus.FAILED),
            "total_human_gates": len(self.human_gates),
            "approved_gates": sum(1 for g in self.human_gates if g.decision == GateDecision.APPROVED),
            "rejected_gates": sum(1 for g in self.human_gates if g.decision == GateDecision.REJECTED),
            "state_updates": len(self.loop_states)
        }
        
        print(f"\n🏁 LoopRun {self.current_loop_run.id} completed")
        print(f"  Status: {self.current_loop_run.status.value}")
        print(f"  Duration: {duration:.2f}s")
        print(f"  Skills executed: {len(self.skill_executions)}")
        print(f"  Human gates: {len(self.human_gates)}")
        print(f"  State updates: {len(self.loop_states)}")

    def get_execution_summary(self) -> Dict[str, Any]:
        """Get a summary of the entire execution."""
        if not self.current_loop_run:
            return {}
        
        return {
            "loop_run": self.current_loop_run.to_dict(),
            "skill_executions": [s.to_dict() for s in self.skill_executions],
            "human_gates": [g.to_dict() for g in self.human_gates],
            "loop_states": {k: s.to_dict() for k, s in self.loop_states.items()}
        }


def main():
    """Demonstrate the travel booking agent workflow."""
    
    print("=" * 60)
    print("TRAVEL BOOKING AGENT - AGENT-BASED AUTOMATION EXAMPLE")
    print("=" * 60)
    
    # Initialize the agent
    agent = TravelBookingAgent()
    
    # User request for travel booking
    user_request = {
        "destination": "Paris",
        "start_date": "2026-10-01",
        "end_date": "2026-10-07",
        "budget": 1000,
        "travelers": 2
    }
    
    # Step 1: Start the loop run
    loop_run = agent.start_booking_process(user_request)
    
    # Step 2: Update initial state
    agent.update_state("destination", user_request["destination"])
    agent.update_state("budget", str(user_request["budget"]), StateType.NUMBER)
    agent.update_state("travelers", str(user_request["travelers"]), StateType.NUMBER)
    
    # Create checkpoint after initial setup
    agent.create_checkpoint("initial_setup", {
        "user_request": user_request,
        "state": {k: s.state_value for k, s in agent.loop_states.items()}
    })
    
    # Step 3: Execute flight search skill
    flight_result = agent.execute_skill("search_flights", {
        "destination": user_request["destination"],
        "date": user_request["start_date"],
        "passengers": user_request["travelers"]
    })
    
    # Step 4: Execute hotel search skill
    hotel_result = agent.execute_skill("search_hotels", {
        "destination": user_request["destination"],
        "check_in": user_request["start_date"],
        "check_out": user_request["end_date"],
        "guests": user_request["travelers"]
    })
    
    # Step 5: Calculate total cost
    cost_result = agent.execute_skill("calculate_total_cost", {
        "flight_cost": flight_result.output_result["best_option"]["price"] * user_request["travelers"],
        "hotel_cost": hotel_result.output_result["best_option"]["price"] * 6,  # 6 nights
        "budget": user_request["budget"]
    })
    
    # Step 6: Create human gate for expensive bookings
    total_cost = cost_result.output_result["total_cost"]
    if total_cost > user_request["budget"] * 0.8:  # If over 80% of budget
        agent.create_human_gate(
            GateType.APPROVAL,
            f"Total cost ${total_cost} is over 80% of budget. Approve?",
            {
                "total_cost": total_cost,
                "budget": user_request["budget"],
                "percentage": (total_cost / user_request["budget"]) * 100
            }
        )
    
    # Step 7: Create booking if approved
    if agent.human_gates and agent.human_gates[-1].decision == GateDecision.APPROVED:
        flight_booking = agent.execute_skill("create_booking", {
            "booking_type": "flight",
            "provider": flight_result.output_result["best_option"]["airline"],
            "details": flight_result.output_result["best_option"]
        })
        
        hotel_booking = agent.execute_skill("create_booking", {
            "booking_type": "hotel",
            "provider": hotel_result.output_result["best_option"]["name"],
            "details": hotel_result.output_result["best_option"]
        })
        
        # Update state with booking information
        agent.update_state("flight_confirmation", flight_booking.output_result["confirmation_code"])
        agent.update_state("hotel_confirmation", hotel_booking.output_result["confirmation_code"])
    
    # Step 8: Create final checkpoint
    agent.create_checkpoint("booking_complete", {
        "bookings": {
            "flight": flight_booking.output_result if flight_booking else None,
            "hotel": hotel_booking.output_result if hotel_booking else None
        },
        "final_state": {k: s.state_value for k, s in agent.loop_states.items()}
    })
    
    # Step 9: Complete the loop run
    agent.complete_loop_run(success=True)
    
    # Print execution summary
    print("\n" + "=" * 60)
    print("EXECUTION SUMMARY")
    print("=" * 60)
    summary = agent.get_execution_summary()
    
    print(f"\n📊 Loop Run Details:")
    print(f"  ID: {summary['loop_run']['id']}")
    print(f"  Status: {summary['loop_run']['status']}")
    print(f"  Duration: {summary['loop_run']['metrics']['duration_seconds']:.2f}s")
    print(f"  Trigger: {summary['loop_run']['trigger_type']}")
    
    print(f"\n🤖 Skill Executions:")
    for skill in summary['skill_executions']:
        status_emoji = "✅" if skill['status'] == 'completed' else "❌"
        print(f"  {status_emoji} {skill['skill_name']} - {skill['execution_time_ms']}ms")
    
    print(f"\n🚦 Human Gates:")
    for gate in summary['human_gates']:
        decision_emoji = "✅" if gate['decision'] == 'approved' else "❌"
        print(f"  {decision_emoji} {gate['gate_type']}: {gate['decision']}")
    
    print(f"\n💾 Loop State:")
    for key, value in summary['loop_states'].items():
        print(f"  {key}: {value['state_value']} ({value['state_type']})")
    
    print(f"\n📸 Checkpoints:")
    for checkpoint_name in summary['loop_run']['checkpoint_data'].keys():
        print(f"  • {checkpoint_name}")
    
    print("\n" + "=" * 60)
    print("Example demonstrates how loop runs provide:")
    print("  • Execution tracking and context")
    print("  • Skill execution monitoring")
    print("  • Human-in-the-loop workflows")
    print("  • State management across operations")
    print("  • Checkpoint/recovery capabilities")
    print("  • Comprehensive metrics and audit trails")
    print("=" * 60)


if __name__ == "__main__":
    main()