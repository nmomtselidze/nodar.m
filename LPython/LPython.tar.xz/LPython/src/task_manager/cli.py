import argparse
import sys
from datetime import datetime
from typing import Optional
from .service import TaskService
from .models import TaskStatus, TaskPriority


def parse_date(date_string: Optional[str]) -> Optional[datetime]:
    if not date_string:
        return None
    try:
        return datetime.fromisoformat(date_string)
    except ValueError:
        print(f"Error: Invalid date format '{date_string}'. Use ISO format (e.g., 2024-01-01 or 2024-01-01T12:00)")
        sys.exit(1)


def format_task(task) -> str:
    status_emoji = {
        TaskStatus.PENDING: "⏳",
        TaskStatus.IN_PROGRESS: "🔄",
        TaskStatus.COMPLETED: "✅",
    }
    priority_emoji = {
        TaskPriority.LOW: "🟢",
        TaskPriority.MEDIUM: "🟡",
        TaskPriority.HIGH: "🔴",
    }
    return (
        f"[{task.id}] {status_emoji.get(task.status, '?')} {priority_emoji.get(task.priority, '?')} {task.title}\n"
        f"    Status: {task.status.value} | Priority: {task.priority.value}\n"
        f"    Created: {task.created_at.strftime('%Y-%m-%d %H:%M')}\n"
        f"    Description: {task.description or 'No description'}"
    )


def cmd_add(args):
    service = TaskService(args.db)
    due_date = parse_date(args.due_date)
    task = service.create_task(
        title=args.title,
        description=args.description or "",
        priority=TaskPriority(args.priority),
        due_date=due_date,
    )
    print(f"✓ Task created with ID: {task.id}")
    print(format_task(task))


def cmd_list(args):
    service = TaskService(args.db)
    tasks = []
    
    if args.status:
        tasks = service.list_tasks_by_status(TaskStatus(args.status))
    elif args.priority:
        tasks = service.list_tasks_by_priority(TaskPriority(args.priority))
    else:
        tasks = service.list_all_tasks()
    
    if not tasks:
        print("No tasks found.")
        return
    
    print(f"\nFound {len(tasks)} task(s):\n")
    for task in tasks:
        print(format_task(task))
        print()


def cmd_show(args):
    service = TaskService(args.db)
    task = service.get_task(args.id)
    if not task:
        print(f"Error: Task with ID {args.id} not found.")
        sys.exit(1)
        return  # Return after sys.exit for test compatibility
    print(format_task(task))


def cmd_update(args):
    service = TaskService(args.db)
    task = service.get_task(args.id)
    if not task:
        print(f"Error: Task with ID {args.id} not found.")
        sys.exit(1)
    
    updated_task = service.update_task_details(
        task_id=args.id,
        title=args.title,
        description=args.description,
        due_date=parse_date(args.due_date),
    )
    
    if updated_task:
        print(f"✓ Task {args.id} updated:")
        print(format_task(updated_task))


def cmd_status(args):
    service = TaskService(args.db)
    task = service.update_task_status(args.id, TaskStatus(args.status))
    if not task:
        print(f"Error: Task with ID {args.id} not found.")
        sys.exit(1)
    print(f"✓ Task {args.id} status changed to {args.status}")
    print(format_task(task))


def cmd_priority(args):
    service = TaskService(args.db)
    task = service.update_task_priority(args.id, TaskPriority(args.priority))
    if not task:
        print(f"Error: Task with ID {args.id} not found.")
        sys.exit(1)
    print(f"✓ Task {args.id} priority changed to {args.priority}")
    print(format_task(task))


def cmd_delete(args):
    service = TaskService(args.db)
    if service.delete_task(args.id):
        print(f"✓ Task {args.id} deleted.")
    else:
        print(f"Error: Task with ID {args.id} not found.")
        sys.exit(1)


def cmd_search(args):
    service = TaskService(args.db)
    tasks = service.search_tasks(args.query)
    if not tasks:
        print(f"No tasks matching '{args.query}' found.")
        return
    print(f"\nFound {len(tasks)} task(s) matching '{args.query}':\n")
    for task in tasks:
        print(format_task(task))
        print()


def cmd_complete(args):
    service = TaskService(args.db)
    task = service.mark_task_complete(args.id)
    if not task:
        print(f"Error: Task with ID {args.id} not found.")
        sys.exit(1)
    print(f"✓ Task {args.id} marked as complete")
    print(format_task(task))


def cmd_clear(args):
    service = TaskService(args.db)
    if service.clear_all_tasks():
        print("✓ All tasks cleared.")
    else:
        print("No tasks to clear.")


def main():
    parser = argparse.ArgumentParser(description="Task Manager CLI")
    parser.add_argument("--db", default="tasks.db", help="Path to database file")
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Add command
    add_parser = subparsers.add_parser("add", help="Add a new task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument("-d", "--description", help="Task description")
    add_parser.add_argument("-p", "--priority", choices=["low", "medium", "high"], 
                           default="medium", help="Task priority")
    add_parser.add_argument("--due-date", help="Due date (ISO format, e.g., 2024-01-01)")
    add_parser.set_defaults(func=cmd_add)
    
    # List command
    list_parser = subparsers.add_parser("list", help="List tasks")
    list_parser.add_argument("-s", "--status", choices=["pending", "in_progress", "completed"],
                            help="Filter by status")
    list_parser.add_argument("-p", "--priority", choices=["low", "medium", "high"],
                            help="Filter by priority")
    list_parser.set_defaults(func=cmd_list)
    
    # Show command
    show_parser = subparsers.add_parser("show", help="Show task details")
    show_parser.add_argument("id", type=int, help="Task ID")
    show_parser.set_defaults(func=cmd_show)
    
    # Update command
    update_parser = subparsers.add_parser("update", help="Update task details")
    update_parser.add_argument("id", type=int, help="Task ID")
    update_parser.add_argument("-t", "--title", help="New title")
    update_parser.add_argument("-d", "--description", help="New description")
    update_parser.add_argument("--due-date", help="New due date (ISO format)")
    update_parser.set_defaults(func=cmd_update)
    
    # Status command
    status_parser = subparsers.add_parser("status", help="Update task status")
    status_parser.add_argument("id", type=int, help="Task ID")
    status_parser.add_argument("status", choices=["pending", "in_progress", "completed"],
                              help="New status")
    status_parser.set_defaults(func=cmd_status)
    
    # Priority command
    priority_parser = subparsers.add_parser("priority", help="Update task priority")
    priority_parser.add_argument("id", type=int, help="Task ID")
    priority_parser.add_argument("priority", choices=["low", "medium", "high"],
                                 help="New priority")
    priority_parser.set_defaults(func=cmd_priority)
    
    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("id", type=int, help="Task ID")
    delete_parser.set_defaults(func=cmd_delete)
    
    # Search command
    search_parser = subparsers.add_parser("search", help="Search tasks")
    search_parser.add_argument("query", help="Search query")
    search_parser.set_defaults(func=cmd_search)
    
    # Complete command
    complete_parser = subparsers.add_parser("complete", help="Mark task as complete")
    complete_parser.add_argument("id", type=int, help="Task ID")
    complete_parser.set_defaults(func=cmd_complete)
    
    # Clear command
    clear_parser = subparsers.add_parser("clear", help="Clear all tasks")
    clear_parser.set_defaults(func=cmd_clear)
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    args.func(args)


if __name__ == "__main__":
    main()
