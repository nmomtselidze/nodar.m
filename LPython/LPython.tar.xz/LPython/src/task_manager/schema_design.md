# Loop Spine Schema Design for Task Manager

## Overview
The Spine provides persistent memory between loop runs, enabling state survival, checkpointing, and human gate tracking.

## Schema Tables

### 1. loop_runs
Tracks each execution of the loop (heartbeat events).

```sql
CREATE TABLE loop_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at TEXT NOT NULL,
    completed_at TEXT,
    status TEXT NOT NULL,  -- 'running', 'completed', 'failed', 'halted'
    trigger_type TEXT NOT NULL,  -- 'schedule', 'event', 'manual', 'conditional'
    trigger_metadata TEXT,  -- JSON: cron schedule, event details, etc.
    tasks_processed INTEGER DEFAULT 0,
    tasks_created INTEGER DEFAULT 0,
    tasks_updated INTEGER DEFAULT 0,
    tasks_deleted INTEGER DEFAULT 0,
    error_message TEXT,
    metrics TEXT,  -- JSON: performance metrics, token usage, etc.
    checkpoint_data TEXT  -- JSON: state snapshot for resume capability
);
```

### 2. skill_executions
Tracks individual skill/function calls within a loop run.

```sql
CREATE TABLE skill_executions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    loop_run_id INTEGER NOT NULL,
    skill_name TEXT NOT NULL,
    started_at TEXT NOT NULL,
    completed_at TEXT,
    status TEXT NOT NULL,  -- 'running', 'completed', 'failed'
    input_params TEXT,  -- JSON: parameters passed to skill
    output_result TEXT,  -- JSON: skill output
    error_message TEXT,
    token_usage INTEGER,  -- tokens consumed
    execution_time_ms INTEGER,
    FOREIGN KEY (loop_run_id) REFERENCES loop_runs(id)
);
```

### 3. human_gates
Tracks decisions requiring human approval/intervention.

```sql
CREATE TABLE human_gates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    loop_run_id INTEGER NOT NULL,
    skill_execution_id INTEGER,
    gate_type TEXT NOT NULL,  -- 'approval', 'confirmation', 'input', 'error_review'
    question TEXT NOT NULL,
    context_data TEXT,  -- JSON: relevant context for decision
    decision TEXT,  -- 'approved', 'rejected', 'deferred'
    human_response TEXT,
    created_at TEXT NOT NULL,
    responded_at TEXT,
    responder_id TEXT,  -- identifier for who responded
    FOREIGN KEY (loop_run_id) REFERENCES loop_runs(id),
    FOREIGN KEY (skill_execution_id) REFERENCES skill_executions(id)
);
```

### 4. loop_configuration
Stores loop settings and heartbeat configuration.

```sql
CREATE TABLE loop_configuration (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    config_key TEXT UNIQUE NOT NULL,
    config_value TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    description TEXT
);
```

### 5. loop_state
Stores current loop state for conditional run-until-done patterns.

```sql
CREATE TABLE loop_state (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    state_key TEXT UNIQUE NOT NULL,
    state_value TEXT NOT NULL,
    state_type TEXT NOT NULL,  -- 'string', 'number', 'boolean', 'json'
    updated_at TEXT NOT NULL,
    persists_across_runs BOOLEAN DEFAULT 1
);
```

### 6. checkpoints
Stores named checkpoints for loop resume capability.

```sql
CREATE TABLE checkpoints (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    checkpoint_name TEXT UNIQUE NOT NULL,
    loop_run_id INTEGER NOT NULL,
    snapshot_data TEXT NOT NULL,  -- JSON: complete state snapshot
    created_at TEXT NOT NULL,
    is_restorable BOOLEAN DEFAULT 1,
    FOREIGN KEY (loop_run_id) REFERENCES loop_runs(id)
);
```

## Indexes

```sql
-- Performance indexes
CREATE INDEX idx_loop_runs_status ON loop_runs(status);
CREATE INDEX idx_loop_runs_started_at ON loop_runs(started_at);
CREATE INDEX idx_skill_executions_loop_run ON skill_executions(loop_run_id);
CREATE INDEX idx_skill_executions_status ON skill_executions(status);
CREATE INDEX idx_human_gates_loop_run ON human_gates(loop_run_id);
CREATE INDEX idx_human_gates_decision ON human_gates(decision);
CREATE INDEX idx_checkpoints_name ON checkpoints(checkpoint_name);
```

## Migration Strategy

### Version 1 → Version 2
- Add all new tables
- Migrate existing tasks data (no changes needed)
- Initialize default loop configuration
- Create initial loop state entries

### Default Configuration Values
```json
{
  "heartbeat_type": "manual",
  "heartbeat_schedule": null,
  "max_consecutive_failures": 3,
  "enable_human_gates": true,
  "checkpoint_interval": 10,
  "auto_resume_on_failure": false
}
```

## Use Cases

### 1. Conditional Run-Until-Done
- Use `loop_state` to track completion conditions
- Loop checks state before each run
- Updates state as tasks progress

### 2. Scheduled Heartbeat
- `loop_runs.trigger_type = 'schedule'`
- `trigger_metadata` stores cron expression
- Track missed schedules via status

### 3. Human Gate Integration
- Skills create `human_gates` entries when approval needed
- Loop halts until gate resolved
- Track response time and patterns

### 4. Skill Performance Monitoring
- `skill_executions` tracks each skill call
- Monitor token usage and execution time
- Identify slow or failing skills

### 5. Checkpoint/Resume
- Create `checkpoints` at key points
- Resume from last checkpoint on failure
- Enable debugging and replay
