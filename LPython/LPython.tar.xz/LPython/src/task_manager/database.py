import sqlite3
import json
from typing import List, Optional, Dict, Any
from pathlib import Path
from datetime import datetime
from .models import (
    Task, TaskStatus, TaskPriority,
    LoopRun, LoopRunStatus, TriggerType,
    SkillExecution, SkillExecutionStatus,
    HumanGate, GateType, GateDecision,
    LoopState, StateType,
    Checkpoint,
    Trip, TripStatus,
    Booking, BookingStatus, BookingType,
    Activity,
    Agent, AgentStatus
)


class Database:
    def __init__(self, db_path: str = "tasks.db"):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Original tasks table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS tasks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    description TEXT,
                    status TEXT NOT NULL,
                    priority TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    due_date TEXT
                )
            """)
            
            # Loop runs table - tracks each execution of the loop
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS loop_runs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    started_at TEXT NOT NULL,
                    completed_at TEXT,
                    status TEXT NOT NULL,
                    trigger_type TEXT NOT NULL,
                    trigger_metadata TEXT,
                    tasks_processed INTEGER DEFAULT 0,
                    tasks_created INTEGER DEFAULT 0,
                    tasks_updated INTEGER DEFAULT 0,
                    tasks_deleted INTEGER DEFAULT 0,
                    error_message TEXT,
                    metrics TEXT,
                    checkpoint_data TEXT
                )
            """)
            
            # Skill executions table - tracks individual skill calls
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS skill_executions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    loop_run_id INTEGER NOT NULL,
                    skill_name TEXT NOT NULL,
                    started_at TEXT NOT NULL,
                    completed_at TEXT,
                    status TEXT NOT NULL,
                    input_params TEXT,
                    output_result TEXT,
                    error_message TEXT,
                    token_usage INTEGER,
                    execution_time_ms INTEGER,
                    FOREIGN KEY (loop_run_id) REFERENCES loop_runs(id)
                )
            """)
            
            # Human gates table - tracks decisions requiring human approval
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS human_gates (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    loop_run_id INTEGER NOT NULL,
                    skill_execution_id INTEGER,
                    gate_type TEXT NOT NULL,
                    question TEXT NOT NULL,
                    context_data TEXT,
                    decision TEXT,
                    human_response TEXT,
                    created_at TEXT NOT NULL,
                    responded_at TEXT,
                    responder_id TEXT,
                    FOREIGN KEY (loop_run_id) REFERENCES loop_runs(id),
                    FOREIGN KEY (skill_execution_id) REFERENCES skill_executions(id)
                )
            """)
            
            # Loop configuration table - stores loop settings
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS loop_configuration (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    config_key TEXT UNIQUE NOT NULL,
                    config_value TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    description TEXT
                )
            """)
            
            # Loop state table - stores current loop state for conditional patterns
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS loop_state (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    state_key TEXT UNIQUE NOT NULL,
                    state_value TEXT NOT NULL,
                    state_type TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    persists_across_runs BOOLEAN DEFAULT 1
                )
            """)
            
            # Checkpoints table - stores named checkpoints for resume capability
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS checkpoints (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    checkpoint_name TEXT UNIQUE NOT NULL,
                    loop_run_id INTEGER NOT NULL,
                    snapshot_data TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    is_restorable BOOLEAN DEFAULT 1,
                    FOREIGN KEY (loop_run_id) REFERENCES loop_runs(id)
                )
            """)
            
            # Trip planning tables
            # Trips table - stores trip information
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS trips (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    destination TEXT NOT NULL,
                    start_date TEXT,
                    end_date TEXT,
                    budget REAL,
                    travelers INTEGER DEFAULT 1,
                    status TEXT NOT NULL,
                    user_requirements TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            
            # Bookings table - stores flight, hotel, and activity bookings
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS bookings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    trip_id INTEGER NOT NULL,
                    booking_type TEXT NOT NULL,
                    status TEXT NOT NULL,
                    provider TEXT,
                    details TEXT,
                    cost REAL,
                    confirmation_code TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY (trip_id) REFERENCES trips(id)
                )
            """)
            
            # Activities table - stores sightseeing and activity information
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS activities (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    trip_id INTEGER NOT NULL,
                    name TEXT NOT NULL,
                    description TEXT,
                    location TEXT,
                    date TEXT,
                    duration_hours REAL,
                    cost REAL,
                    booking_id INTEGER,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY (trip_id) REFERENCES trips(id),
                    FOREIGN KEY (booking_id) REFERENCES bookings(id)
                )
            """)
            
            # Agents table - stores agent information and status
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS agents (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    agent_type TEXT NOT NULL,
                    status TEXT NOT NULL,
                    current_task TEXT,
                    capabilities TEXT,
                    last_activity TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            
            # Create indexes for performance
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_loop_runs_status ON loop_runs(status)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_loop_runs_started_at ON loop_runs(started_at)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_skill_executions_loop_run ON skill_executions(loop_run_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_skill_executions_status ON skill_executions(status)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_human_gates_loop_run ON human_gates(loop_run_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_human_gates_decision ON human_gates(decision)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_checkpoints_name ON checkpoints(checkpoint_name)")
            
            # Trip planning indexes
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_trips_status ON trips(status)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_trips_destination ON trips(destination)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_bookings_trip_id ON bookings(trip_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_bookings_type ON bookings(booking_type)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_activities_trip_id ON activities(trip_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_activities_date ON activities(date)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_agents_type ON agents(agent_type)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_agents_status ON agents(status)")
            
            # Initialize default configuration if not exists
            self._init_default_config(cursor)
            
            conn.commit()

    def _init_default_config(self, cursor):
        from datetime import datetime
        default_configs = {
            "heartbeat_type": "manual",
            "heartbeat_schedule": "",
            "max_consecutive_failures": "3",
            "enable_human_gates": "true",
            "checkpoint_interval": "10",
            "auto_resume_on_failure": "false",
        }
        
        for key, value in default_configs.items():
            cursor.execute("""
                INSERT OR IGNORE INTO loop_configuration (config_key, config_value, updated_at, description)
                VALUES (?, ?, ?, ?)
            """, (key, value, datetime.now().isoformat(), f"Default configuration for {key}"))

    def add_task(self, task: Task) -> Task:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO tasks (title, description, status, priority, created_at, updated_at, due_date)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                task.title,
                task.description,
                task.status.value,
                task.priority.value,
                task.created_at.isoformat(),
                task.updated_at.isoformat(),
                task.due_date.isoformat() if task.due_date else None,
            ))
            conn.commit()
            task.id = cursor.lastrowid
            return task

    def get_task(self, task_id: int) -> Optional[Task]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM tasks WHERE id = ?", (task_id,))
            row = cursor.fetchone()
            if row:
                return self._row_to_task(row)
            return None

    def get_all_tasks(self) -> List[Task]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM tasks")
            rows = cursor.fetchall()
            return [self._row_to_task(row) for row in rows]

    def update_task(self, task: Task) -> bool:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE tasks 
                SET title = ?, description = ?, status = ?, priority = ?, updated_at = ?, due_date = ?
                WHERE id = ?
            """, (
                task.title,
                task.description,
                task.status.value,
                task.priority.value,
                task.updated_at.isoformat(),
                task.due_date.isoformat() if task.due_date else None,
                task.id,
            ))
            conn.commit()
            return cursor.rowcount > 0

    def delete_task(self, task_id: int) -> bool:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
            conn.commit()
            return cursor.rowcount > 0

    def get_tasks_by_status(self, status: TaskStatus) -> List[Task]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM tasks WHERE status = ?", (status.value,))
            rows = cursor.fetchall()
            return [self._row_to_task(row) for row in rows]

    def get_tasks_by_priority(self, priority: TaskPriority) -> List[Task]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM tasks WHERE priority = ?", (priority.value,))
            rows = cursor.fetchall()
            return [self._row_to_task(row) for row in rows]

    def _row_to_task(self, row) -> Task:
        from datetime import datetime
        return Task(
            id=row[0],
            title=row[1],
            description=row[2],
            status=TaskStatus(row[3]),
            priority=TaskPriority(row[4]),
            created_at=datetime.fromisoformat(row[5]),
            updated_at=datetime.fromisoformat(row[6]),
            due_date=datetime.fromisoformat(row[7]) if row[7] else None,
        )

    def clear_all_tasks(self) -> bool:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM tasks")
            conn.commit()
            return cursor.rowcount > 0

    # Loop Run Methods
    def create_loop_run(self, loop_run: LoopRun) -> LoopRun:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO loop_runs (
                    started_at, completed_at, status, trigger_type, trigger_metadata,
                    tasks_processed, tasks_created, tasks_updated, tasks_deleted,
                    error_message, metrics, checkpoint_data
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                loop_run.started_at.isoformat(),
                loop_run.completed_at.isoformat() if loop_run.completed_at else None,
                loop_run.status.value,
                loop_run.trigger_type.value,
                json.dumps(loop_run.trigger_metadata) if loop_run.trigger_metadata else None,
                loop_run.tasks_processed,
                loop_run.tasks_created,
                loop_run.tasks_updated,
                loop_run.tasks_deleted,
                loop_run.error_message,
                json.dumps(loop_run.metrics) if loop_run.metrics else None,
                json.dumps(loop_run.checkpoint_data) if loop_run.checkpoint_data else None,
            ))
            conn.commit()
            loop_run.id = cursor.lastrowid
            return loop_run

    def get_loop_run(self, run_id: int) -> Optional[LoopRun]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM loop_runs WHERE id = ?", (run_id,))
            row = cursor.fetchone()
            if row:
                return self._row_to_loop_run(row)
            return None

    def update_loop_run(self, loop_run: LoopRun) -> bool:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE loop_runs
                SET completed_at = ?, status = ?, tasks_processed = ?,
                    tasks_created = ?, tasks_updated = ?, tasks_deleted = ?,
                    error_message = ?, metrics = ?, checkpoint_data = ?
                WHERE id = ?
            """, (
                loop_run.completed_at.isoformat() if loop_run.completed_at else None,
                loop_run.status.value,
                loop_run.tasks_processed,
                loop_run.tasks_created,
                loop_run.tasks_updated,
                loop_run.tasks_deleted,
                loop_run.error_message,
                json.dumps(loop_run.metrics) if loop_run.metrics else None,
                json.dumps(loop_run.checkpoint_data) if loop_run.checkpoint_data else None,
                loop_run.id,
            ))
            conn.commit()
            return cursor.rowcount > 0

    def get_recent_loop_runs(self, limit: int = 10) -> List[LoopRun]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM loop_runs ORDER BY started_at DESC LIMIT ?", (limit,))
            rows = cursor.fetchall()
            return [self._row_to_loop_run(row) for row in rows]

    def _row_to_loop_run(self, row) -> LoopRun:
        return LoopRun(
            id=row[0],
            started_at=datetime.fromisoformat(row[1]),
            completed_at=datetime.fromisoformat(row[2]) if row[2] else None,
            status=LoopRunStatus(row[3]),
            trigger_type=TriggerType(row[4]),
            trigger_metadata=json.loads(row[5]) if row[5] else None,
            tasks_processed=row[6],
            tasks_created=row[7],
            tasks_updated=row[8],
            tasks_deleted=row[9],
            error_message=row[10],
            metrics=json.loads(row[11]) if row[11] else None,
            checkpoint_data=json.loads(row[12]) if row[12] else None,
        )

    # Skill Execution Methods
    def create_skill_execution(self, skill_exec: SkillExecution) -> SkillExecution:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO skill_executions (
                    loop_run_id, skill_name, started_at, completed_at, status,
                    input_params, output_result, error_message, token_usage, execution_time_ms
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                skill_exec.loop_run_id,
                skill_exec.skill_name,
                skill_exec.started_at.isoformat(),
                skill_exec.completed_at.isoformat() if skill_exec.completed_at else None,
                skill_exec.status.value,
                json.dumps(skill_exec.input_params) if skill_exec.input_params else None,
                json.dumps(skill_exec.output_result) if skill_exec.output_result else None,
                skill_exec.error_message,
                skill_exec.token_usage,
                skill_exec.execution_time_ms,
            ))
            conn.commit()
            skill_exec.id = cursor.lastrowid
            return skill_exec

    def update_skill_execution(self, skill_exec: SkillExecution) -> bool:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE skill_executions
                SET completed_at = ?, status = ?, output_result = ?,
                    error_message = ?, token_usage = ?, execution_time_ms = ?
                WHERE id = ?
            """, (
                skill_exec.completed_at.isoformat() if skill_exec.completed_at else None,
                skill_exec.status.value,
                json.dumps(skill_exec.output_result) if skill_exec.output_result else None,
                skill_exec.error_message,
                skill_exec.token_usage,
                skill_exec.execution_time_ms,
                skill_exec.id,
            ))
            conn.commit()
            return cursor.rowcount > 0

    def get_skill_executions_for_run(self, loop_run_id: int) -> List[SkillExecution]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM skill_executions WHERE loop_run_id = ?", (loop_run_id,))
            rows = cursor.fetchall()
            return [self._row_to_skill_execution(row) for row in rows]

    def _row_to_skill_execution(self, row) -> SkillExecution:
        return SkillExecution(
            id=row[0],
            loop_run_id=row[1],
            skill_name=row[2],
            started_at=datetime.fromisoformat(row[3]),
            completed_at=datetime.fromisoformat(row[4]) if row[4] else None,
            status=SkillExecutionStatus(row[5]),
            input_params=json.loads(row[6]) if row[6] else None,
            output_result=json.loads(row[7]) if row[7] else None,
            error_message=row[8],
            token_usage=row[9],
            execution_time_ms=row[10],
        )

    # Human Gate Methods
    def create_human_gate(self, gate: HumanGate) -> HumanGate:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO human_gates (
                    loop_run_id, skill_execution_id, gate_type, question, context_data,
                    decision, human_response, created_at, responded_at, responder_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                gate.loop_run_id,
                gate.skill_execution_id,
                gate.gate_type.value,
                gate.question,
                json.dumps(gate.context_data) if gate.context_data else None,
                gate.decision.value if gate.decision else None,
                gate.human_response,
                gate.created_at.isoformat(),
                gate.responded_at.isoformat() if gate.responded_at else None,
                gate.responder_id,
            ))
            conn.commit()
            gate.id = cursor.lastrowid
            return gate

    def update_human_gate(self, gate: HumanGate) -> bool:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE human_gates
                SET decision = ?, human_response = ?, responded_at = ?, responder_id = ?
                WHERE id = ?
            """, (
                gate.decision.value if gate.decision else None,
                gate.human_response,
                gate.responded_at.isoformat() if gate.responded_at else None,
                gate.responder_id,
                gate.id,
            ))
            conn.commit()
            return cursor.rowcount > 0

    def get_pending_gates(self) -> List[HumanGate]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM human_gates WHERE decision IS NULL ORDER BY created_at")
            rows = cursor.fetchall()
            return [self._row_to_human_gate(row) for row in rows]

    def get_gates_for_run(self, loop_run_id: int) -> List[HumanGate]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM human_gates WHERE loop_run_id = ?", (loop_run_id,))
            rows = cursor.fetchall()
            return [self._row_to_human_gate(row) for row in rows]

    def _row_to_human_gate(self, row) -> HumanGate:
        return HumanGate(
            id=row[0],
            loop_run_id=row[1],
            skill_execution_id=row[2],
            gate_type=GateType(row[3]),
            question=row[4],
            context_data=json.loads(row[5]) if row[5] else None,
            decision=GateDecision(row[6]) if row[6] else None,
            human_response=row[7],
            created_at=datetime.fromisoformat(row[8]),
            responded_at=datetime.fromisoformat(row[9]) if row[9] else None,
            responder_id=row[10],
        )

    # Loop State Methods
    def set_loop_state(self, state: LoopState) -> LoopState:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO loop_state (state_key, state_value, state_type, updated_at, persists_across_runs)
                VALUES (?, ?, ?, ?, ?)
            """, (
                state.state_key,
                state.state_value,
                state.state_type.value,
                state.updated_at.isoformat(),
                state.persists_across_runs,
            ))
            conn.commit()
            if not state.id:
                state.id = cursor.lastrowid
            return state

    def get_loop_state(self, state_key: str) -> Optional[LoopState]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM loop_state WHERE state_key = ?", (state_key,))
            row = cursor.fetchone()
            if row:
                return self._row_to_loop_state(row)
            return None

    def get_all_loop_state(self) -> List[LoopState]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM loop_state")
            rows = cursor.fetchall()
            return [self._row_to_loop_state(row) for row in rows]

    def delete_loop_state(self, state_key: str) -> bool:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM loop_state WHERE state_key = ?", (state_key,))
            conn.commit()
            return cursor.rowcount > 0

    def _row_to_loop_state(self, row) -> LoopState:
        return LoopState(
            id=row[0],
            state_key=row[1],
            state_value=row[2],
            state_type=StateType(row[3]),
            updated_at=datetime.fromisoformat(row[4]),
            persists_across_runs=row[5],
        )

    # Checkpoint Methods
    def create_checkpoint(self, checkpoint: Checkpoint) -> Checkpoint:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO checkpoints (checkpoint_name, loop_run_id, snapshot_data, created_at, is_restorable)
                VALUES (?, ?, ?, ?, ?)
            """, (
                checkpoint.checkpoint_name,
                checkpoint.loop_run_id,
                json.dumps(checkpoint.snapshot_data) if checkpoint.snapshot_data else None,
                checkpoint.created_at.isoformat(),
                checkpoint.is_restorable,
            ))
            conn.commit()
            checkpoint.id = cursor.lastrowid
            return checkpoint

    def get_checkpoint(self, checkpoint_name: str) -> Optional[Checkpoint]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM checkpoints WHERE checkpoint_name = ?", (checkpoint_name,))
            row = cursor.fetchone()
            if row:
                return self._row_to_checkpoint(row)
            return None

    def get_checkpoints_for_run(self, loop_run_id: int) -> List[Checkpoint]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM checkpoints WHERE loop_run_id = ?", (loop_run_id,))
            rows = cursor.fetchall()
            return [self._row_to_checkpoint(row) for row in rows]

    def delete_checkpoint(self, checkpoint_name: str) -> bool:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM checkpoints WHERE checkpoint_name = ?", (checkpoint_name,))
            conn.commit()
            return cursor.rowcount > 0

    def _row_to_checkpoint(self, row) -> Checkpoint:
        return Checkpoint(
            id=row[0],
            checkpoint_name=row[1],
            loop_run_id=row[2],
            snapshot_data=json.loads(row[3]) if row[3] else None,
            created_at=datetime.fromisoformat(row[4]),
            is_restorable=row[5],
        )

    # Configuration Methods
    def set_config(self, key: str, value: str, description: str = "") -> bool:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO loop_configuration (config_key, config_value, updated_at, description)
                VALUES (?, ?, ?, ?)
            """, (key, value, datetime.now().isoformat(), description))
            conn.commit()
            return True

    def get_config(self, key: str) -> Optional[str]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT config_value FROM loop_configuration WHERE config_key = ?", (key,))
            row = cursor.fetchone()
            return row[0] if row else None

    def get_all_config(self) -> Dict[str, str]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT config_key, config_value FROM loop_configuration")
            rows = cursor.fetchall()
            return {row[0]: row[1] for row in rows}

    # Trip Planning Methods
    def create_trip(self, trip: Trip) -> Trip:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO trips (destination, start_date, end_date, budget, travelers, status, user_requirements, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                trip.destination,
                trip.start_date.isoformat() if trip.start_date else None,
                trip.end_date.isoformat() if trip.end_date else None,
                trip.budget,
                trip.travelers,
                trip.status.value,
                json.dumps(trip.user_requirements) if trip.user_requirements else None,
                trip.created_at.isoformat(),
                trip.updated_at.isoformat(),
            ))
            conn.commit()
            trip.id = cursor.lastrowid
            return trip

    def get_trip(self, trip_id: int) -> Optional[Trip]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM trips WHERE id = ?", (trip_id,))
            row = cursor.fetchone()
            if row:
                return self._row_to_trip(row)
            return None

    def update_trip(self, trip: Trip) -> bool:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE trips
                SET destination = ?, start_date = ?, end_date = ?, budget = ?, travelers = ?, status = ?, user_requirements = ?, updated_at = ?
                WHERE id = ?
            """, (
                trip.destination,
                trip.start_date.isoformat() if trip.start_date else None,
                trip.end_date.isoformat() if trip.end_date else None,
                trip.budget,
                trip.travelers,
                trip.status.value,
                json.dumps(trip.user_requirements) if trip.user_requirements else None,
                trip.updated_at.isoformat(),
                trip.id,
            ))
            conn.commit()
            return cursor.rowcount > 0

    def get_all_trips(self) -> List[Trip]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM trips ORDER BY created_at DESC")
            rows = cursor.fetchall()
            return [self._row_to_trip(row) for row in rows]

    def _row_to_trip(self, row) -> Trip:
        return Trip(
            id=row[0],
            destination=row[1],
            start_date=datetime.fromisoformat(row[2]) if row[2] else None,
            end_date=datetime.fromisoformat(row[3]) if row[3] else None,
            budget=row[4],
            travelers=row[5],
            status=TripStatus(row[6]),
            user_requirements=json.loads(row[7]) if row[7] else None,
            created_at=datetime.fromisoformat(row[8]),
            updated_at=datetime.fromisoformat(row[9]),
        )

    def create_booking(self, booking: Booking) -> Booking:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO bookings (trip_id, booking_type, status, provider, details, cost, confirmation_code, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                booking.trip_id,
                booking.booking_type.value,
                booking.status.value,
                booking.provider,
                json.dumps(booking.details) if booking.details else None,
                booking.cost,
                booking.confirmation_code,
                booking.created_at.isoformat(),
                booking.updated_at.isoformat(),
            ))
            conn.commit()
            booking.id = cursor.lastrowid
            return booking

    def get_bookings_for_trip(self, trip_id: int) -> List[Booking]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM bookings WHERE trip_id = ?", (trip_id,))
            rows = cursor.fetchall()
            return [self._row_to_booking(row) for row in rows]

    def update_booking(self, booking: Booking) -> bool:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE bookings
                SET status = ?, provider = ?, details = ?, cost = ?, confirmation_code = ?, updated_at = ?
                WHERE id = ?
            """, (
                booking.status.value,
                booking.provider,
                json.dumps(booking.details) if booking.details else None,
                booking.cost,
                booking.confirmation_code,
                booking.updated_at.isoformat(),
                booking.id,
            ))
            conn.commit()
            return cursor.rowcount > 0

    def _row_to_booking(self, row) -> Booking:
        return Booking(
            id=row[0],
            trip_id=row[1],
            booking_type=BookingType(row[2]),
            status=BookingStatus(row[3]),
            provider=row[4],
            details=json.loads(row[5]) if row[5] else None,
            cost=row[6],
            confirmation_code=row[7],
            created_at=datetime.fromisoformat(row[8]),
            updated_at=datetime.fromisoformat(row[9]),
        )

    def create_activity(self, activity: Activity) -> Activity:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO activities (trip_id, name, description, location, date, duration_hours, cost, booking_id, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                activity.trip_id,
                activity.name,
                activity.description,
                activity.location,
                activity.date.isoformat() if activity.date else None,
                activity.duration_hours,
                activity.cost,
                activity.booking_id,
                activity.created_at.isoformat(),
                activity.updated_at.isoformat(),
            ))
            conn.commit()
            activity.id = cursor.lastrowid
            return activity

    def get_activities_for_trip(self, trip_id: int) -> List[Activity]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM activities WHERE trip_id = ?", (trip_id,))
            rows = cursor.fetchall()
            return [self._row_to_activity(row) for row in rows]

    def _row_to_activity(self, row) -> Activity:
        return Activity(
            id=row[0],
            trip_id=row[1],
            name=row[2],
            description=row[3],
            location=row[4],
            date=datetime.fromisoformat(row[5]) if row[5] else None,
            duration_hours=row[6],
            cost=row[7],
            booking_id=row[8],
            created_at=datetime.fromisoformat(row[9]),
            updated_at=datetime.fromisoformat(row[10]),
        )

    def create_agent(self, agent: Agent) -> Agent:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO agents (agent_type, status, current_task, capabilities, last_activity, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                agent.agent_type,
                agent.status.value,
                agent.current_task,
                json.dumps(agent.capabilities) if agent.capabilities else None,
                agent.last_activity.isoformat() if agent.last_activity else None,
                agent.created_at.isoformat(),
                agent.updated_at.isoformat(),
            ))
            conn.commit()
            agent.id = cursor.lastrowid
            return agent

    def get_agent_by_type(self, agent_type: str) -> Optional[Agent]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM agents WHERE agent_type = ?", (agent_type,))
            row = cursor.fetchone()
            if row:
                return self._row_to_agent(row)
            return None

    def update_agent(self, agent: Agent) -> bool:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE agents
                SET status = ?, current_task = ?, capabilities = ?, last_activity = ?, updated_at = ?
                WHERE id = ?
            """, (
                agent.status.value,
                agent.current_task,
                json.dumps(agent.capabilities) if agent.capabilities else None,
                agent.last_activity.isoformat() if agent.last_activity else None,
                agent.updated_at.isoformat(),
                agent.id,
            ))
            conn.commit()
            return cursor.rowcount > 0

    def get_all_agents(self) -> List[Agent]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM agents")
            rows = cursor.fetchall()
            return [self._row_to_agent(row) for row in rows]

    def _row_to_agent(self, row) -> Agent:
        return Agent(
            id=row[0],
            agent_type=row[1],
            status=AgentStatus(row[2]),
            current_task=row[3],
            capabilities=json.loads(row[4]) if row[4] else None,
            last_activity=datetime.fromisoformat(row[5]) if row[5] else None,
            created_at=datetime.fromisoformat(row[6]),
            updated_at=datetime.fromisoformat(row[7]),
        )
