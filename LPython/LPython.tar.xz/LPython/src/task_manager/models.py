from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, Dict, Any
from enum import Enum


class TaskStatus(Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"


class TaskPriority(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class LoopRunStatus(Enum):
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    HALTED = "halted"


class TriggerType(Enum):
    SCHEDULE = "schedule"
    EVENT = "event"
    MANUAL = "manual"
    CONDITIONAL = "conditional"


class SkillExecutionStatus(Enum):
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class GateType(Enum):
    APPROVAL = "approval"
    CONFIRMATION = "confirmation"
    INPUT = "input"
    ERROR_REVIEW = "error_review"


class GateDecision(Enum):
    APPROVED = "approved"
    REJECTED = "rejected"
    DEFERRED = "deferred"


class StateType(Enum):
    STRING = "string"
    NUMBER = "number"
    BOOLEAN = "boolean"
    JSON = "json"


class BookingStatus(Enum):
    PENDING = "pending"
    CONFIRMED = "confirmed"
    CANCELLED = "cancelled"
    FAILED = "failed"


class BookingType(Enum):
    FLIGHT = "flight"
    HOTEL = "hotel"
    ACTIVITY = "activity"


class AgentStatus(Enum):
    IDLE = "idle"
    WORKING = "working"
    COMPLETED = "completed"
    ERROR = "error"


class TripStatus(Enum):
    PLANNING = "planning"
    BOOKING = "booking"
    CONFIRMED = "confirmed"
    CANCELLED = "cancelled"
    COMPLETED = "completed"


@dataclass
class Task:
    id: Optional[int] = None
    title: str = ""
    description: str = ""
    status: TaskStatus = TaskStatus.PENDING
    priority: TaskPriority = TaskPriority.MEDIUM
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    due_date: Optional[datetime] = None

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "status": self.status.value,
            "priority": self.priority.value,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "due_date": self.due_date.isoformat() if self.due_date else None,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Task":
        return cls(
            id=data.get("id"),
            title=data.get("title", ""),
            description=data.get("description", ""),
            status=TaskStatus(data.get("status", TaskStatus.PENDING.value)),
            priority=TaskPriority(data.get("priority", TaskPriority.MEDIUM.value)),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else datetime.now(),
            updated_at=datetime.fromisoformat(data["updated_at"]) if data.get("updated_at") else datetime.now(),
            due_date=datetime.fromisoformat(data["due_date"]) if data.get("due_date") else None,
        )


@dataclass
class LoopRun:
    id: Optional[int] = None
    started_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None
    status: LoopRunStatus = LoopRunStatus.RUNNING
    trigger_type: TriggerType = TriggerType.MANUAL
    trigger_metadata: Optional[Dict[str, Any]] = None
    tasks_processed: int = 0
    tasks_created: int = 0
    tasks_updated: int = 0
    tasks_deleted: int = 0
    error_message: Optional[str] = None
    metrics: Optional[Dict[str, Any]] = None
    checkpoint_data: Optional[Dict[str, Any]] = None

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "status": self.status.value,
            "trigger_type": self.trigger_type.value,
            "trigger_metadata": self.trigger_metadata,
            "tasks_processed": self.tasks_processed,
            "tasks_created": self.tasks_created,
            "tasks_updated": self.tasks_updated,
            "tasks_deleted": self.tasks_deleted,
            "error_message": self.error_message,
            "metrics": self.metrics,
            "checkpoint_data": self.checkpoint_data,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "LoopRun":
        return cls(
            id=data.get("id"),
            started_at=datetime.fromisoformat(data["started_at"]) if data.get("started_at") else datetime.now(),
            completed_at=datetime.fromisoformat(data["completed_at"]) if data.get("completed_at") else None,
            status=LoopRunStatus(data.get("status", LoopRunStatus.RUNNING.value)),
            trigger_type=TriggerType(data.get("trigger_type", TriggerType.MANUAL.value)),
            trigger_metadata=data.get("trigger_metadata"),
            tasks_processed=data.get("tasks_processed", 0),
            tasks_created=data.get("tasks_created", 0),
            tasks_updated=data.get("tasks_updated", 0),
            tasks_deleted=data.get("tasks_deleted", 0),
            error_message=data.get("error_message"),
            metrics=data.get("metrics"),
            checkpoint_data=data.get("checkpoint_data"),
        )


@dataclass
class SkillExecution:
    id: Optional[int] = None
    loop_run_id: Optional[int] = None
    skill_name: str = ""
    started_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None
    status: SkillExecutionStatus = SkillExecutionStatus.RUNNING
    input_params: Optional[Dict[str, Any]] = None
    output_result: Optional[Dict[str, Any]] = None
    error_message: Optional[str] = None
    token_usage: Optional[int] = None
    execution_time_ms: Optional[int] = None

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "loop_run_id": self.loop_run_id,
            "skill_name": self.skill_name,
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "status": self.status.value,
            "input_params": self.input_params,
            "output_result": self.output_result,
            "error_message": self.error_message,
            "token_usage": self.token_usage,
            "execution_time_ms": self.execution_time_ms,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "SkillExecution":
        return cls(
            id=data.get("id"),
            loop_run_id=data.get("loop_run_id"),
            skill_name=data.get("skill_name", ""),
            started_at=datetime.fromisoformat(data["started_at"]) if data.get("started_at") else datetime.now(),
            completed_at=datetime.fromisoformat(data["completed_at"]) if data.get("completed_at") else None,
            status=SkillExecutionStatus(data.get("status", SkillExecutionStatus.RUNNING.value)),
            input_params=data.get("input_params"),
            output_result=data.get("output_result"),
            error_message=data.get("error_message"),
            token_usage=data.get("token_usage"),
            execution_time_ms=data.get("execution_time_ms"),
        )


@dataclass
class HumanGate:
    id: Optional[int] = None
    loop_run_id: Optional[int] = None
    skill_execution_id: Optional[int] = None
    gate_type: GateType = GateType.APPROVAL
    question: str = ""
    context_data: Optional[Dict[str, Any]] = None
    decision: Optional[GateDecision] = None
    human_response: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    responded_at: Optional[datetime] = None
    responder_id: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "loop_run_id": self.loop_run_id,
            "skill_execution_id": self.skill_execution_id,
            "gate_type": self.gate_type.value,
            "question": self.question,
            "context_data": self.context_data,
            "decision": self.decision.value if self.decision else None,
            "human_response": self.human_response,
            "created_at": self.created_at.isoformat(),
            "responded_at": self.responded_at.isoformat() if self.responded_at else None,
            "responder_id": self.responder_id,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "HumanGate":
        return cls(
            id=data.get("id"),
            loop_run_id=data.get("loop_run_id"),
            skill_execution_id=data.get("skill_execution_id"),
            gate_type=GateType(data.get("gate_type", GateType.APPROVAL.value)),
            question=data.get("question", ""),
            context_data=data.get("context_data"),
            decision=GateDecision(data["decision"]) if data.get("decision") else None,
            human_response=data.get("human_response"),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else datetime.now(),
            responded_at=datetime.fromisoformat(data["responded_at"]) if data.get("responded_at") else None,
            responder_id=data.get("responder_id"),
        )


@dataclass
class LoopState:
    id: Optional[int] = None
    state_key: str = ""
    state_value: str = ""
    state_type: StateType = StateType.STRING
    updated_at: datetime = field(default_factory=datetime.now)
    persists_across_runs: bool = True

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "state_key": self.state_key,
            "state_value": self.state_value,
            "state_type": self.state_type.value,
            "updated_at": self.updated_at.isoformat(),
            "persists_across_runs": self.persists_across_runs,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "LoopState":
        return cls(
            id=data.get("id"),
            state_key=data.get("state_key", ""),
            state_value=data.get("state_value", ""),
            state_type=StateType(data.get("state_type", StateType.STRING.value)),
            updated_at=datetime.fromisoformat(data["updated_at"]) if data.get("updated_at") else datetime.now(),
            persists_across_runs=data.get("persists_across_runs", True),
        )


@dataclass
class Checkpoint:
    id: Optional[int] = None
    checkpoint_name: str = ""
    loop_run_id: Optional[int] = None
    snapshot_data: Optional[Dict[str, Any]] = None
    created_at: datetime = field(default_factory=datetime.now)
    is_restorable: bool = True

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "checkpoint_name": self.checkpoint_name,
            "loop_run_id": self.loop_run_id,
            "snapshot_data": self.snapshot_data,
            "created_at": self.created_at.isoformat(),
            "is_restorable": self.is_restorable,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Checkpoint":
        return cls(
            id=data.get("id"),
            checkpoint_name=data.get("checkpoint_name", ""),
            loop_run_id=data.get("loop_run_id"),
            snapshot_data=data.get("snapshot_data"),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else datetime.now(),
            is_restorable=data.get("is_restorable", True),
        )


@dataclass
class Trip:
    id: Optional[int] = None
    destination: str = ""
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    budget: Optional[float] = None
    travelers: int = 1
    status: TripStatus = TripStatus.PLANNING
    user_requirements: Optional[Dict[str, Any]] = None
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "destination": self.destination,
            "start_date": self.start_date.isoformat() if self.start_date else None,
            "end_date": self.end_date.isoformat() if self.end_date else None,
            "budget": self.budget,
            "travelers": self.travelers,
            "status": self.status.value,
            "user_requirements": self.user_requirements,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Trip":
        return cls(
            id=data.get("id"),
            destination=data.get("destination", ""),
            start_date=datetime.fromisoformat(data["start_date"]) if data.get("start_date") else None,
            end_date=datetime.fromisoformat(data["end_date"]) if data.get("end_date") else None,
            budget=data.get("budget"),
            travelers=data.get("travelers", 1),
            status=TripStatus(data.get("status", TripStatus.PLANNING.value)),
            user_requirements=data.get("user_requirements"),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else datetime.now(),
            updated_at=datetime.fromisoformat(data["updated_at"]) if data.get("updated_at") else datetime.now(),
        )


@dataclass
class Booking:
    id: Optional[int] = None
    trip_id: Optional[int] = None
    booking_type: BookingType = BookingType.FLIGHT
    status: BookingStatus = BookingStatus.PENDING
    provider: str = ""
    details: Optional[Dict[str, Any]] = None
    cost: Optional[float] = None
    confirmation_code: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "trip_id": self.trip_id,
            "booking_type": self.booking_type.value,
            "status": self.status.value,
            "provider": self.provider,
            "details": self.details,
            "cost": self.cost,
            "confirmation_code": self.confirmation_code,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Booking":
        return cls(
            id=data.get("id"),
            trip_id=data.get("trip_id"),
            booking_type=BookingType(data.get("booking_type", BookingType.FLIGHT.value)),
            status=BookingStatus(data.get("status", BookingStatus.PENDING.value)),
            provider=data.get("provider", ""),
            details=data.get("details"),
            cost=data.get("cost"),
            confirmation_code=data.get("confirmation_code"),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else datetime.now(),
            updated_at=datetime.fromisoformat(data["updated_at"]) if data.get("updated_at") else datetime.now(),
        )


@dataclass
class Activity:
    id: Optional[int] = None
    trip_id: Optional[int] = None
    name: str = ""
    description: str = ""
    location: str = ""
    date: Optional[datetime] = None
    duration_hours: Optional[float] = None
    cost: Optional[float] = None
    booking_id: Optional[int] = None
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "trip_id": self.trip_id,
            "name": self.name,
            "description": self.description,
            "location": self.location,
            "date": self.date.isoformat() if self.date else None,
            "duration_hours": self.duration_hours,
            "cost": self.cost,
            "booking_id": self.booking_id,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Activity":
        return cls(
            id=data.get("id"),
            trip_id=data.get("trip_id"),
            name=data.get("name", ""),
            description=data.get("description", ""),
            location=data.get("location", ""),
            date=datetime.fromisoformat(data["date"]) if data.get("date") else None,
            duration_hours=data.get("duration_hours"),
            cost=data.get("cost"),
            booking_id=data.get("booking_id"),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else datetime.now(),
            updated_at=datetime.fromisoformat(data["updated_at"]) if data.get("updated_at") else datetime.now(),
        )


@dataclass
class Agent:
    id: Optional[int] = None
    agent_type: str = ""  # "FlightAgent", "HotelAgent", "SightseeingAgent"
    status: AgentStatus = AgentStatus.IDLE
    current_task: Optional[str] = None
    capabilities: Optional[list[str]] = None
    last_activity: Optional[datetime] = None
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "agent_type": self.agent_type,
            "status": self.status.value,
            "current_task": self.current_task,
            "capabilities": self.capabilities,
            "last_activity": self.last_activity.isoformat() if self.last_activity else None,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Agent":
        return cls(
            id=data.get("id"),
            agent_type=data.get("agent_type", ""),
            status=AgentStatus(data.get("status", AgentStatus.IDLE.value)),
            current_task=data.get("current_task"),
            capabilities=data.get("capabilities"),
            last_activity=datetime.fromisoformat(data["last_activity"]) if data.get("last_activity") else None,
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else datetime.now(),
            updated_at=datetime.fromisoformat(data["updated_at"]) if data.get("updated_at") else datetime.now(),
        )
