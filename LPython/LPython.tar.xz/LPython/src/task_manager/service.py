from datetime import datetime
from typing import List, Optional
from .models import Task, TaskStatus, TaskPriority
from .database import Database


class TaskService:
    def __init__(self, db_path: str = "tasks.db"):
        self.db = Database(db_path)

    def create_task(
        self,
        title: str,
        description: str = "",
        priority: TaskPriority = TaskPriority.MEDIUM,
        due_date: Optional[datetime] = None,
    ) -> Task:
        task = Task(
            title=title,
            description=description,
            priority=priority,
            due_date=due_date,
        )
        return self.db.add_task(task)

    def get_task(self, task_id: int) -> Optional[Task]:
        return self.db.get_task(task_id)

    def list_all_tasks(self) -> List[Task]:
        return self.db.get_all_tasks()

    def list_tasks_by_status(self, status: TaskStatus) -> List[Task]:
        return self.db.get_tasks_by_status(status)

    def list_tasks_by_priority(self, priority: TaskPriority) -> List[Task]:
        return self.db.get_tasks_by_priority(priority)

    def update_task_status(self, task_id: int, status: TaskStatus) -> Optional[Task]:
        task = self.db.get_task(task_id)
        if task:
            task.status = status
            task.updated_at = datetime.now()
            self.db.update_task(task)
            return task
        return None

    def update_task_priority(self, task_id: int, priority: TaskPriority) -> Optional[Task]:
        task = self.db.get_task(task_id)
        if task:
            task.priority = priority
            task.updated_at = datetime.now()
            self.db.update_task(task)
            return task
        return None

    def update_task_details(
        self,
        task_id: int,
        title: Optional[str] = None,
        description: Optional[str] = None,
        due_date: Optional[datetime] = None,
    ) -> Optional[Task]:
        task = self.db.get_task(task_id)
        if task:
            if title is not None:
                task.title = title
            if description is not None:
                task.description = description
            if due_date is not None:
                task.due_date = due_date
            task.updated_at = datetime.now()
            self.db.update_task(task)
            return task
        return None

    def delete_task(self, task_id: int) -> bool:
        return self.db.delete_task(task_id)

    def search_tasks(self, query: str) -> List[Task]:
        all_tasks = self.db.get_all_tasks()
        return [
            task for task in all_tasks
            if query.lower() in task.title.lower() or query.lower() in task.description.lower()
        ]

    def get_pending_tasks(self) -> List[Task]:
        return self.list_tasks_by_status(TaskStatus.PENDING)

    def get_in_progress_tasks(self) -> List[Task]:
        return self.list_tasks_by_status(TaskStatus.IN_PROGRESS)

    def get_completed_tasks(self) -> List[Task]:
        return self.list_tasks_by_status(TaskStatus.COMPLETED)

    def get_high_priority_tasks(self) -> List[Task]:
        return self.list_tasks_by_priority(TaskPriority.HIGH)

    def mark_task_complete(self, task_id: int) -> Optional[Task]:
        return self.update_task_status(task_id, TaskStatus.COMPLETED)

    def mark_task_in_progress(self, task_id: int) -> Optional[Task]:
        return self.update_task_status(task_id, TaskStatus.IN_PROGRESS)

    def clear_all_tasks(self) -> bool:
        return self.db.clear_all_tasks()
